
import React from 'react';
import { Link } from 'react-router-dom';
import { TUTORIALS, CATEGORIES } from '../constants';
import TutorialCard from '../components/TutorialCard';

const CategoryIconLink: React.FC<{ category: typeof CATEGORIES[0] }> = ({ category }) => (
    <Link to="/tutorials" state={{ category: category.name }} className="flex flex-col items-center text-center group">
        <div className={`w-20 h-20 rounded-full flex items-center justify-center ${category.bgColor} group-hover:scale-110 transition-transform duration-300 shadow-sm`}>
            <category.icon className={`w-10 h-10 ${category.color}`} />
        </div>
        <span className="mt-3 font-semibold text-gray-700 group-hover:text-green-600">{category.name}</span>
    </Link>
);

export default function Home(): React.ReactElement {
  const featuredTutorials = TUTORIALS.slice(0, 3);

  return (
    <div className="space-y-24 pb-24">
      {/* Hero Section */}
      <section className="bg-white">
        <div className="container mx-auto px-6 py-20 text-center">
            <div className="max-w-4xl mx-auto">
                <h1 className="text-5xl md:text-7xl font-bold text-gray-800 leading-tight">
                    Prototype. <span className="text-green-500">Create.</span> Play.
                </h1>
                <p className="mt-6 text-xl text-gray-600">
                    Learn, build, and explore. STEM made fun for everyone.
                </p>
                <div className="mt-10 flex justify-center gap-4">
                    <Link to="/tutorials" className="bg-green-500 text-white font-semibold px-8 py-3 rounded-full hover:bg-green-600 transition-all duration-300 shadow-md hover:shadow-lg transform hover:-translate-y-0.5">
                        Explore Tutorials
                    </Link>
                    <Link to="/about" className="bg-gray-200 text-gray-800 font-semibold px-8 py-3 rounded-full hover:bg-gray-300 transition-all duration-300">
                        Learn More
                    </Link>
                </div>
            </div>
        </div>
      </section>

      {/* Featured Tutorials Section */}
      <section className="container mx-auto px-6">
        <h2 className="text-4xl font-bold text-center text-gray-800">Featured Tutorials</h2>
        <div className="mt-12 grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {featuredTutorials.map((tutorial) => (
            <TutorialCard key={tutorial.slug} tutorial={tutorial} />
          ))}
        </div>
      </section>

      {/* Categories Section */}
      <section className="container mx-auto px-6">
        <h2 className="text-4xl font-bold text-center text-gray-800">Explore by Category</h2>
        <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-8">
            {CATEGORIES.map(cat => <CategoryIconLink key={cat.slug} category={cat} />)}
        </div>
      </section>

      {/* Mission Section */}
      <section className="container mx-auto px-6">
        <div className="bg-white rounded-2xl shadow-lg p-10 md:p-16 text-center max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-gray-800">Welcome to Protopals!</h2>
          <p className="mt-4 text-lg text-gray-600">
            Our mission is to spark curiosity and creativity through hands-on STEM projects. We provide free, easy-to-follow tutorials that make learning about science, technology, engineering, and math an exciting adventure for everyone.
          </p>
        </div>
      </section>
    </div>
  );
}
