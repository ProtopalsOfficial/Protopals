
import React from 'react';
import { CATEGORIES } from '../constants';
import CategoryTile from '../components/CategoryTile';

export default function Categories(): React.ReactElement {
  return (
    <div className="container mx-auto px-6 py-12">
      <div className="text-center mb-12">
        <h1 className="text-5xl font-bold text-gray-800">Categories</h1>
        <p className="mt-4 text-lg text-gray-600">Discover projects based on your interests.</p>
      </div>

      <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-2 max-w-4xl mx-auto">
        {CATEGORIES.map((category) => (
          <CategoryTile key={category.slug} category={category} />
        ))}
      </div>
    </div>
  );
}
