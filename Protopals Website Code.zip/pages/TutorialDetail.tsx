
import React from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { TUTORIALS } from '../constants';
import { useFavorites } from '../context/FavoritesContext';
import TutorialCard from '../components/TutorialCard';

const StarIcon = ({ filled }: { filled: boolean }) => (
  <svg className={`w-6 h-6 transition-colors ${filled ? 'text-yellow-400' : 'text-gray-400'}`} fill="currentColor" viewBox="0 0 20 20">
    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
  </svg>
);

const PrintIcon = () => (
    <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"></path></svg>
);

export default function TutorialDetail(): React.ReactElement {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const { isFavorite, addFavorite, removeFavorite } = useFavorites();
  const tutorial = TUTORIALS.find((t) => t.slug === slug);
  
  if (!tutorial) {
    return <div className="text-center py-20">Tutorial not found.</div>;
  }
  
  const handlePrint = () => {
    window.print();
  };

  const relatedTutorials = TUTORIALS.filter(t => t.category === tutorial.category && t.slug !== tutorial.slug).slice(0, 3);

  const favorited = isFavorite(tutorial.slug);
  const toggleFavorite = () => {
    if(favorited) {
        removeFavorite(tutorial.slug);
    } else {
        addFavorite(tutorial.slug);
    }
  };

  return (
    <div className="bg-white">
      <div className="container mx-auto px-6 py-16">
        <div className="max-w-4xl mx-auto print:max-w-full">
            <div className="mb-8">
                <button onClick={() => navigate('/tutorials')} className="text-green-600 hover:underline print:hidden">&larr; Back to Tutorials</button>
            </div>
          {/* Header */}
          <div className="text-center mb-10">
            <p className="text-green-600 font-semibold">{tutorial.category}</p>
            <h1 className="text-4xl md:text-5xl font-bold text-gray-800 mt-2">{tutorial.title}</h1>
            <div className="mt-4 text-sm text-gray-500 flex justify-center items-center gap-4">
              <span>By {tutorial.author}</span>
              <span>&bull;</span>
              <span>{tutorial.date}</span>
              <span>&bull;</span>
              <span className="px-2 py-1 text-xs font-semibold rounded-full bg-gray-100 text-gray-800">{tutorial.difficulty}</span>
            </div>
          </div>
          
          <div className="flex flex-col lg:flex-row gap-12 print:flex-row">
            {/* Main Content */}
            <div className="w-full lg:w-2/3 print:w-2/3">
              {tutorial.videoUrl && (
                  <div className="mb-8 aspect-w-16 aspect-h-9 rounded-lg overflow-hidden shadow-lg">
                      <iframe src={tutorial.videoUrl} title={tutorial.title} frameBorder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen className="w-full h-full"></iframe>
                  </div>
              )}
               {!tutorial.videoUrl && (
                  <div className="mb-8 rounded-lg overflow-hidden shadow-lg">
                      <img src={tutorial.thumbnail} alt={tutorial.title} className="w-full h-auto object-cover"/>
                  </div>
               )}

              <p className="text-lg text-gray-600 mb-8">{tutorial.description}</p>

              <h2 className="text-3xl font-bold mb-6 border-b pb-3">Steps</h2>
              <ol className="space-y-8">
                {tutorial.steps.map((step, index) => (
                  <li key={index} className="flex gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-green-500 text-white rounded-full flex items-center justify-center font-bold text-lg">{index + 1}</div>
                    <div className="flex-grow">
                      <h3 className="text-xl font-semibold mb-2">{step.title}</h3>
                      <p className="text-gray-600">{step.description}</p>
                      {step.image && <img src={step.image} alt={`Step ${index + 1}`} className="mt-4 rounded-lg shadow-sm" />}
                    </div>
                  </li>
                ))}
              </ol>
            </div>

            {/* Sidebar */}
            <div className="w-full lg:w-1/3 print:w-1/3">
              <div className="sticky top-24 space-y-6 print:sticky-auto">
                <div className="flex gap-2 print:hidden">
                    <button onClick={toggleFavorite} className="flex-1 flex items-center justify-center gap-2 bg-gray-100 text-gray-700 font-semibold px-4 py-3 rounded-full hover:bg-gray-200 transition-colors">
                        <StarIcon filled={favorited}/>
                        {favorited ? 'Favorited' : 'Favorite'}
                    </button>
                    <button onClick={handlePrint} className="flex-1 flex items-center justify-center bg-gray-100 text-gray-700 font-semibold px-4 py-3 rounded-full hover:bg-gray-200 transition-colors">
                        <PrintIcon />
                        Print
                    </button>
                </div>
                <div className="bg-gray-50 p-6 rounded-lg border">
                  <h3 className="text-2xl font-bold mb-4">Materials</h3>
                  <ul className="list-disc list-inside space-y-2 text-gray-700">
                    {tutorial.materials.map((item, index) => <li key={index}>{item}</li>)}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Related Tutorials */}
      {relatedTutorials.length > 0 && (
          <div className="bg-gray-50 py-16 print:hidden">
            <div className="container mx-auto px-6">
              <h2 className="text-3xl font-bold text-center mb-10">Related Tutorials</h2>
              <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3 max-w-5xl mx-auto">
                {relatedTutorials.map(t => <TutorialCard key={t.slug} tutorial={t} />)}
              </div>
            </div>
          </div>
      )}
    </div>
  );
}
