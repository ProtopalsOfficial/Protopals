
import React from 'react';
import { RobotIcon, GearIcon, BeakerIcon, ScissorsIcon } from '../constants';

const ValueCard: React.FC<{ icon: React.ReactNode; title: string; children: React.ReactNode }> = ({ icon, title, children }) => (
    <div className="bg-white p-6 rounded-lg shadow-sm text-center">
        <div className="flex justify-center mb-4">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center text-green-500">
                {icon}
            </div>
        </div>
        <h3 className="text-xl font-bold text-gray-800">{title}</h3>
        <p className="mt-2 text-gray-600">{children}</p>
    </div>
);

export default function About(): React.ReactElement {
  return (
    <div className="bg-white">
      <div className="container mx-auto px-6 py-16">
        <div className="max-w-4xl mx-auto">
          <div className="text-center">
            <RobotIcon className="mx-auto h-20 w-20 text-green-500" />
            <h1 className="text-5xl font-bold text-gray-800 mt-4">About Protopals</h1>
            <p className="mt-6 text-xl text-gray-600">
              Our mission is to inspire the next generation of innovators, creators, and problem-solvers.
            </p>
          </div>

          <div className="mt-16 text-lg text-gray-700 space-y-6 text-left md:text-justify">
            <p>
              Protopals is a vibrant online community where curiosity meets creativity. We believe that learning about Science, Technology, Engineering, and Math (STEM) should be an exciting, hands-on adventure. That's why we provide a growing library of free, high-quality tutorials and project instructions designed to be fun and accessible for everyone, from curious kids to seasoned hobbyists.
            </p>
            <p>
              Whether you're building your first robot, conducting a fizzy science experiment, or engineering a mechanical marvel, Protopals is here to guide you. Our goal is to break down complex topics into simple, engaging steps, empowering you to not just follow along, but to truly understand, innovate, and create something amazing.
            </p>
          </div>

          <div className="mt-20">
            <h2 className="text-4xl font-bold text-center text-gray-800">Our Core Values</h2>
            <div className="mt-10 grid md:grid-cols-2 gap-8">
                <ValueCard icon={<BeakerIcon className="w-8 h-8"/>} title="Curiosity">
                    We encourage asking "why?" and "what if?". Every great invention starts with a question.
                </ValueCard>
                <ValueCard icon={<GearIcon className="w-8 h-8"/>} title="Creativity">
                    We celebrate unique ideas and provide the tools to bring them to life. There's no single right way to build.
                </ValueCard>
                <ValueCard icon={<RobotIcon className="w-8 h-8"/>} title="Exploration">
                    We champion hands-on learning and the joy of discovery through trial and error.
                </ValueCard>
                <ValueCard icon={<ScissorsIcon className="w-8 h-8"/>} title="Community">
                    We aim to build a supportive space where learners can share their creations and inspire one another.
                </ValueCard>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
