
import React, { useState, useMemo } from 'react';
import { useLocation } from 'react-router-dom';
import { TUTORIALS, CATEGORIES } from '../constants';
import TutorialCard from '../components/TutorialCard';
import type { Category } from '../types';

export default function Tutorials(): React.ReactElement {
  const location = useLocation();
  const initialCategory = location.state?.category || 'All';
  
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<Category['name'] | 'All'>(initialCategory);

  const filteredTutorials = useMemo(() => {
    return TUTORIALS.filter(tutorial => {
      const matchesCategory = selectedCategory === 'All' || tutorial.category === selectedCategory;
      const matchesSearch = tutorial.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            tutorial.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            tutorial.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
      return matchesCategory && matchesSearch;
    });
  }, [searchTerm, selectedCategory]);
  
  const handleCategoryClick = (category: Category['name'] | 'All') => {
    setSelectedCategory(category);
  };

  return (
    <div className="container mx-auto px-6 py-12">
      <div className="text-center mb-12">
        <h1 className="text-5xl font-bold text-gray-800">All Tutorials</h1>
        <p className="mt-4 text-lg text-gray-600">Find your next project and start creating!</p>
      </div>

      {/* Filters */}
      <div className="mb-10 flex flex-col md:flex-row gap-4">
        <div className="relative flex-grow">
          <input
            type="text"
            placeholder="Search tutorials..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full px-4 py-3 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-green-500"
          />
        </div>
        <div className="flex-shrink-0 bg-white border border-gray-200 p-1.5 rounded-full flex space-x-1 overflow-x-auto">
          <button
            onClick={() => handleCategoryClick('All')}
            className={`px-4 py-2 rounded-full text-sm font-semibold transition-colors ${selectedCategory === 'All' ? 'bg-green-500 text-white' : 'text-gray-600 hover:bg-gray-100'}`}
          >
            All
          </button>
          {CATEGORIES.map(cat => (
            <button
              key={cat.slug}
              onClick={() => handleCategoryClick(cat.name)}
              className={`px-4 py-2 rounded-full text-sm font-semibold transition-colors whitespace-nowrap ${selectedCategory === cat.name ? 'bg-green-500 text-white' : 'text-gray-600 hover:bg-gray-100'}`}
            >
              {cat.name}
            </button>
          ))}
        </div>
      </div>

      {/* Tutorial Grid */}
      {filteredTutorials.length > 0 ? (
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {filteredTutorials.map((tutorial) => (
            <TutorialCard key={tutorial.slug} tutorial={tutorial} />
          ))}
        </div>
      ) : (
        <div className="text-center py-16">
            <p className="text-xl text-gray-500">No tutorials found. Try a different search or filter!</p>
        </div>
      )}
    </div>
  );
}
