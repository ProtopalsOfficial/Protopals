
import React, { createContext, useState, useEffect, useContext, ReactNode } from 'react';

interface FavoritesContextType {
  favorites: string[];
  addFavorite: (slug: string) => void;
  removeFavorite: (slug: string) => void;
  isFavorite: (slug: string) => boolean;
}

const FavoritesContext = createContext<FavoritesContextType | undefined>(undefined);

export const FavoritesProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      const item = window.localStorage.getItem('protopals_favorites');
      return item ? JSON.parse(item) : [];
    } catch (error) {
      console.error('Error reading from localStorage', error);
      return [];
    }
  });

  useEffect(() => {
    try {
      window.localStorage.setItem('protopals_favorites', JSON.stringify(favorites));
    } catch (error) {
      console.error('Error writing to localStorage', error);
    }
  }, [favorites]);

  const addFavorite = (slug: string): void => {
    setFavorites((prev) => [...prev, slug]);
  };

  const removeFavorite = (slug: string): void => {
    setFavorites((prev) => prev.filter((fav) => fav !== slug));
  };

  const isFavorite = (slug: string): boolean => {
    return favorites.includes(slug);
  };
  
  const value = { favorites, addFavorite, removeFavorite, isFavorite };

  return (
    <FavoritesContext.Provider value={value}>
      {children}
    </FavoritesContext.Provider>
  );
};

export const useFavorites = (): FavoritesContextType => {
  const context = useContext(FavoritesContext);
  if (context === undefined) {
    throw new Error('useFavorites must be used within a FavoritesProvider');
  }
  return context;
};
