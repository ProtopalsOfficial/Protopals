
import React from 'react';
import type { Tutorial } from '../types';
import { Link } from 'react-router-dom';

const DifficultyBadge: React.FC<{ difficulty: Tutorial['difficulty'] }> = ({ difficulty }) => {
  const color =
    difficulty === 'Beginner' ? 'bg-green-100 text-green-800' :
    difficulty === 'Intermediate' ? 'bg-yellow-100 text-yellow-800' :
    'bg-red-100 text-red-800';
  return (
    <span className={`px-2 py-1 text-xs font-semibold rounded-full ${color}`}>
      {difficulty}
    </span>
  );
};

export default function TutorialCard({ tutorial }: { tutorial: Tutorial }): React.ReactElement {
  return (
    <Link to={`/tutorial/${tutorial.slug}`} className="group block bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
      <div className="relative">
        <img 
          className="h-48 w-full object-cover group-hover:scale-105 transition-transform duration-300" 
          src={tutorial.thumbnail} 
          alt={tutorial.title}
          loading="lazy"
        />
        <div className="absolute top-3 right-3">
          <DifficultyBadge difficulty={tutorial.difficulty} />
        </div>
      </div>
      <div className="p-6">
        <p className="text-sm font-semibold text-green-600 uppercase tracking-wide">{tutorial.category}</p>
        <h3 className="mt-2 text-xl font-bold text-gray-900 group-hover:text-green-600 transition-colors">{tutorial.title}</h3>
        <p className="mt-2 text-gray-500 text-sm">{tutorial.description}</p>
        <div className="mt-4 text-xs text-gray-400 flex items-center justify-between">
            <span>{tutorial.time}</span>
            <span>{tutorial.author}</span>
        </div>
      </div>
    </Link>
  );
}
