
import React from 'react';
import { NavLink } from 'react-router-dom';
import { RobotIcon } from '../constants';

const NavItem: React.FC<{ to: string; children: React.ReactNode }> = ({ to, children }) => {
  const activeClass = 'text-green-500';
  const inactiveClass = 'text-gray-600 hover:text-green-500';
  return (
    <NavLink
      to={to}
      className={({ isActive }) => 
        `px-3 py-2 rounded-md text-sm font-semibold transition-colors ${isActive ? activeClass : inactiveClass}`
      }
    >
      {children}
    </NavLink>
  );
};


export default function Header(): React.ReactElement {
  return (
    <header className="bg-white/80 backdrop-blur-sm sticky top-0 z-50 shadow-sm print:hidden">
      <nav className="container mx-auto px-6 py-4 flex justify-between items-center">
        <NavLink to="/" className="flex items-center gap-2">
          <RobotIcon className="h-8 w-8 text-green-500"/>
          <span className="text-2xl font-bold text-gray-800">Protopals</span>
        </NavLink>
        <div className="flex items-center space-x-2">
          <NavItem to="/">Home</NavItem>
          <NavItem to="/tutorials">Tutorials</NavItem>
          <NavItem to="/categories">Categories</NavItem>
          <NavItem to="/about">About</NavItem>
        </div>
      </nav>
    </header>
  );
}
