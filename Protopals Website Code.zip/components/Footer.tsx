import React from 'react';
import { Link } from 'react-router-dom';

const SocialIcon: React.FC<{ href: string; children: React.ReactNode }> = ({ href, children }) => (
  <a href={href} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-green-500 transition-colors">
    {children}
  </a>
);

const YoutubeIcon = () => (
    <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
        <path fillRule="evenodd" d="M19.802 7.022a2.43 2.43 0 00-1.718-1.718C16.632 5 12 5 12 5s-4.632 0-6.084.304a2.43 2.43 0 00-1.718 1.718C4 8.474 4 12 4 12s0 3.526.198 4.978a2.43 2.43 0 001.718 1.718C7.368 19 12 19 12 19s4.632 0 6.084-.304a2.43 2.43 0 001.718-1.718C20 15.526 20 12 20 12s0-3.526-.198-4.978zM9.546 14.423V9.577l4.333 2.423-4.333 2.423z" clipRule="evenodd" />
    </svg>
);
const InstagramIcon = () => (
    <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M7.8,2H16.2C19.4,2 22,4.6 22,7.8V16.2A5.2,5.2 0 0,1 16.2,21.4H7.8C4.6,21.4 2,18.8 2,15.2V7.8A5.2,5.2 0 0,1 7.8,2M7.6,4A3.6,3.6 0 0,0 4,7.6V16.4C4,18.39 5.61,20 7.6,20H16.4A3.6,3.6 0 0,0 20,16.4V7.6C20,5.61 18.39,4 16.4,4H7.6M17.25,5.5A1.25,1.25 0 0,1 18.5,6.75A1.25,1.25 0 0,1 17.25,8A1.25,1.25 0 0,1 16,6.75A1.25,1.25 0 0,1 17.25,5.5M12,7A5,5 0 0,1 17,12A5,5 0 0,1 12,17A5,5 0 0,1 7,12A5,5 0 0,1 12,7M12,9A3,3 0 0,0 9,12A3,3 0 0,0 12,15A3,3 0 0,0 15,12A3,3 0 0,0 12,9Z" /></svg>
);
const DiscordIcon = () => (
    <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M19.27,5.33C17.94,4.71 16.5,4.26 15,4A.07.07 0 0,0 15,4.07A10.72,10.72 0 0,0 14.13,6.33A12.6,12.6 0 0,0 9.87,6.33A10.77,10.77 0 0,0 9,4.07A.07.07 0 0,0 9,4C7.5,4.26 6.06,4.71 4.73,5.33A.07.07 0 0,0 4.73,5.33C3.07,8.64 2.39,11.62 2.56,14.5A16.39,16.39 0 0,0 6.14,19.35A.07.07 0 0,0 6.21,19.35C6.67,18.93 7.11,18.5 7.5,18.05A.07.07 0 0,0 7.5,18C7.14,17.65 6.78,17.29 6.47,16.92A.07.07 0 0,0 6.39,16.84C6.41,16.81 6.44,16.78 6.46,16.75C6.16,16.28 5.89,15.79 5.66,15.28A.07.07 0 0,0 5.66,15.28C5.66,15.28 5.65,15.27 5.65,15.27C5.23,14.07 5,12.84 5,11.57C5,10.37 5.23,9.22 5.69,8.12A.07.07 0 0,0 5.69,8.12C5.69,8.12 5.69,8.12 5.7,8.12C6.16,7.12 6.78,6.21 7.5,5.45A.07.07 0 0,0 7.5,5.45C8.39,6.13 9.21,6.74 10,7.29A.07.07 0 0,0 10,7.29C10.43,7.56 10.84,7.82 11.22,8.05A.07.07 0 0,0 11.22,8.05A11.08,11.08 0 0,0 12,8.35A11.08,11.08 0 0,0 12.78,8.05A.07.07 0 0,0 12.78,8.05C13.16,7.82 13.57,7.56 14,7.29A.07.07 0 0,0 14,7.29C14.79,6.74 15.61,6.13 16.5,5.45A.07.07 0 0,0 16.5,5.45C17.22,6.21 17.84,7.12 18.3,8.12A.07.07 0 0,0 18.3,8.12C18.31,8.12 18.31,8.12 18.31,8.12C18.77,9.22 19,10.37 19,11.57C19,12.84 18.77,14.07 18.35,15.27C18.35,15.27 18.34,15.27 18.34,15.28A.07.07 0 0,0 18.34,15.28C18.11,15.79 17.84,16.28 17.54,16.75C17.56,16.78 17.59,16.81 17.61,16.84A.07.07 0 0,0 17.53,16.92C17.22,17.29 16.86,17.65 16.5,18A.07.07 0 0,0 16.5,18.05C16.89,18.5 17.33,18.93 17.79,19.35A.07.07 0 0,0 17.86,19.35A16.39,16.39 0 0,0 21.44,14.5C21.61,11.62 20.93,8.64 19.27,5.33Z" /></svg>
);

export default function Footer(): React.ReactElement {
  return (
    <footer className="bg-white border-t border-gray-200 print:hidden">
      <div className="container mx-auto px-6 py-8">
        <div className="flex flex-col md:flex-row justify-between items-center text-center md:text-left">
          <div className="mb-6 md:mb-0">
            <h3 className="text-lg font-bold text-gray-800">Protopals</h3>
            <p className="text-gray-500 mt-1">Learn, build, and explore.</p>
          </div>
          <div className="flex flex-col md:flex-row items-center">
            <div className="flex space-x-6 text-gray-600 font-medium mb-6 md:mb-0 md:mr-10">
              <Link to="/" className="hover:text-green-500 transition-colors">Home</Link>
              <Link to="/tutorials" className="hover:text-green-500 transition-colors">Tutorials</Link>
              <Link to="/categories" className="hover:text-green-500 transition-colors">Categories</Link>
              <Link to="/about" className="hover:text-green-500 transition-colors">About</Link>
            </div>
            <div className="flex space-x-6">
              <SocialIcon href="https://youtube.com"><YoutubeIcon /></SocialIcon>
              <SocialIcon href="https://instagram.com"><InstagramIcon /></SocialIcon>
              <SocialIcon href="https://discord.com"><DiscordIcon /></SocialIcon>
            </div>
          </div>
        </div>
        <div className="mt-8 border-t border-gray-100 pt-6 text-center text-sm text-gray-400">
          <p>© 2025 Protopals. Made with 💚 for curious minds.</p>
        </div>
      </div>
    </footer>
  );
}