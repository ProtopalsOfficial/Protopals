
import React from 'react';
import type { Category } from '../types';
import { Link } from 'react-router-dom';

export default function CategoryTile({ category }: { category: Category }): React.ReactElement {
  return (
    <Link 
      to="/tutorials" 
      state={{ category: category.name }}
      className="group block p-8 rounded-2xl shadow-sm hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1"
      style={{ backgroundColor: 'white' }}
    >
        <div className={`w-16 h-16 rounded-xl flex items-center justify-center ${category.bgColor}`}>
            <category.icon className={`w-8 h-8 ${category.color}`} />
        </div>
        <h3 className="mt-4 text-xl font-bold text-gray-800 group-hover:text-green-600 transition-colors">{category.name}</h3>
        <p className="mt-1 text-gray-500">{category.description}</p>
    </Link>
  );
}
