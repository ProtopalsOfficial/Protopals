// In-memory storage for tutorials and user preferences
// This handles tutorial content management and user data persistence

import type { Tutorial, Category, UserPreferences } from "@shared/schema";

export interface IStorage {
  // Tutorial management
  getAllTutorials(): Promise<Tutorial[]>;
  getTutorialBySlug(slug: string): Promise<Tutorial | null>;
  getTutorialsByCategory(category: string): Promise<Tutorial[]>;
  searchTutorials(query: string): Promise<Tutorial[]>;
  
  // Category management
  getAllCategories(): Promise<Category[]>;
  getCategoryBySlug(slug: string): Promise<Category | null>;
  
  // User preferences (localStorage will be used on frontend)
  getUserPreferences(userId: string): Promise<UserPreferences>;
  updateUserPreferences(userId: string, preferences: Partial<UserPreferences>): Promise<UserPreferences>;
}

export class MemStorage implements IStorage {
  private tutorials: Map<string, Tutorial> = new Map();
  private categories: Map<string, Category> = new Map();
  private userPreferences: Map<string, UserPreferences> = new Map();

  constructor() {
    // Initialize with some basic data
    this.initializeData();
  }

  private async initializeData() {
    // Load MDX tutorials and categories from filesystem
    const { mdxLoader } = await import("./lib/mdx-loader");
    
    try {
      const tutorials = await mdxLoader.loadAllTutorials();
      tutorials.forEach(tutorial => this.addTutorial(tutorial));
      
      const categories = await mdxLoader.getCategories();
      categories.forEach(category => this.addCategory(category));
      
      console.log(`Loaded ${tutorials.length} tutorials and ${categories.length} categories`);
    } catch (error) {
      console.error("Failed to initialize MDX data:", error);
    }
  }

  async getAllTutorials(): Promise<Tutorial[]> {
    return Array.from(this.tutorials.values());
  }

  async getTutorialBySlug(slug: string): Promise<Tutorial | null> {
    return this.tutorials.get(slug) || null;
  }

  async getTutorialsByCategory(category: string): Promise<Tutorial[]> {
    const tutorials = Array.from(this.tutorials.values());
    return tutorials.filter(t => t.frontmatter.category === category);
  }

  async searchTutorials(query: string): Promise<Tutorial[]> {
    const tutorials = Array.from(this.tutorials.values());
    const queryLower = query.toLowerCase();
    
    return tutorials.filter(tutorial => 
      tutorial.frontmatter.title.toLowerCase().includes(queryLower) ||
      tutorial.frontmatter.description.toLowerCase().includes(queryLower) ||
      tutorial.frontmatter.tags.some(tag => tag.toLowerCase().includes(queryLower)) ||
      tutorial.frontmatter.category.toLowerCase().includes(queryLower)
    );
  }

  async getAllCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }

  async getCategoryBySlug(slug: string): Promise<Category | null> {
    return this.categories.get(slug) || null;
  }

  async getUserPreferences(userId: string): Promise<UserPreferences> {
    return this.userPreferences.get(userId) || {
      favoritesTutorials: [],
      materialChecklists: {},
      theme: "system",
    };
  }

  async updateUserPreferences(userId: string, preferences: Partial<UserPreferences>): Promise<UserPreferences> {
    const current = await this.getUserPreferences(userId);
    const updated = { ...current, ...preferences };
    this.userPreferences.set(userId, updated);
    return updated;
  }

  // Method to add tutorials (for MDX loading)
  addTutorial(tutorial: Tutorial) {
    this.tutorials.set(tutorial.slug, tutorial);
  }

  // Method to add categories (for dynamic category generation)
  addCategory(category: Category) {
    this.categories.set(category.slug, category);
  }
}

export const storage = new MemStorage();
