import type { Express } from "express";
import { createServer, type Server } from "http";
import { Router } from "express";
import { storage } from "./storage";
import { searchFiltersSchema } from "@shared/schema";

const router = Router();

// Get all tutorials with optional filtering
router.get("/api/tutorials", async (req, res) => {
  try {
    const filters = searchFiltersSchema.parse({
      query: req.query.search || "",
      category: req.query.category || undefined,
      difficulty: req.query.difficulty || undefined,
      sort: req.query.sort || "newest",
      page: parseInt(req.query.page as string) || 1,
    });

    let tutorials = await storage.getAllTutorials();

    // Apply search filter
    if (filters.query) {
      tutorials = await storage.searchTutorials(filters.query);
    }

    // Apply category filter
    if (filters.category) {
      tutorials = tutorials.filter(t => t.frontmatter.category === filters.category);
    }

    // Apply difficulty filter
    if (filters.difficulty) {
      tutorials = tutorials.filter(t => t.frontmatter.difficulty === filters.difficulty);
    }

    // Apply sorting
    switch (filters.sort) {
      case "popular":
        // TODO: implement real popularity sorting
        tutorials = [...tutorials].sort(() => Math.random() - 0.5);
        break;
      case "difficulty":
        tutorials = [...tutorials].sort((a, b) => {
          const order = { 'Beginner': 1, 'Intermediate': 2, 'Advanced': 3 };
          return order[a.frontmatter.difficulty] - order[b.frontmatter.difficulty];
        });
        break;
      case "duration":
        tutorials = [...tutorials].sort((a, b) => {
          const getDuration = (dur: string) => parseInt(dur) || 0;
          return getDuration(a.frontmatter.duration) - getDuration(b.frontmatter.duration);
        });
        break;
      case "newest":
      default:
        tutorials = [...tutorials].sort((a, b) => 
          new Date(b.frontmatter.date).getTime() - new Date(a.frontmatter.date).getTime()
        );
        break;
    }

    // Pagination
    const PAGE_SIZE = 12;
    const totalCount = tutorials.length;
    const totalPages = Math.ceil(totalCount / PAGE_SIZE);
    const startIndex = (filters.page - 1) * PAGE_SIZE;
    const paginatedTutorials = tutorials.slice(startIndex, startIndex + PAGE_SIZE);

    res.json({
      tutorials: paginatedTutorials,
      pagination: {
        currentPage: filters.page,
        totalPages,
        totalCount,
        hasNext: filters.page < totalPages,
        hasPrev: filters.page > 1,
      },
      filters,
    });
  } catch (error) {
    console.error("Error fetching tutorials:", error);
    res.status(500).json({ error: "Failed to fetch tutorials" });
  }
});

// Get single tutorial by slug
router.get("/api/tutorials/:slug", async (req, res) => {
  try {
    const { slug } = req.params;
    const tutorial = await storage.getTutorialBySlug(slug);
    
    if (!tutorial) {
      return res.status(404).json({ error: "Tutorial not found" });
    }

    res.json(tutorial);
  } catch (error) {
    console.error("Error fetching tutorial:", error);
    res.status(500).json({ error: "Failed to fetch tutorial" });
  }
});

// Get all categories
router.get("/api/categories", async (req, res) => {
  try {
    const categories = await storage.getAllCategories();
    res.json(categories);
  } catch (error) {
    console.error("Error fetching categories:", error);
    res.status(500).json({ error: "Failed to fetch categories" });
  }
});

// Get tutorials by category
router.get("/api/categories/:slug/tutorials", async (req, res) => {
  try {
    const { slug } = req.params;
    const category = await storage.getCategoryBySlug(slug);
    
    if (!category) {
      return res.status(404).json({ error: "Category not found" });
    }

    const tutorials = await storage.getTutorialsByCategory(category.name);
    res.json({
      category,
      tutorials,
    });
  } catch (error) {
    console.error("Error fetching category tutorials:", error);
    res.status(500).json({ error: "Failed to fetch category tutorials" });
  }
});

// Search tutorials
router.get("/api/search", async (req, res) => {
  try {
    const query = req.query.q as string;
    
    if (!query || query.trim().length === 0) {
      return res.json({ tutorials: [] });
    }

    const tutorials = await storage.searchTutorials(query.trim());
    res.json({ tutorials, query });
  } catch (error) {
    console.error("Error searching tutorials:", error);
    res.status(500).json({ error: "Failed to search tutorials" });
  }
});

// User preferences endpoints (for future auth integration)
router.get("/api/user/preferences", async (req, res) => {
  try {
    // For now, return default preferences since we don't have auth
    const defaultUserId = "anonymous";
    const preferences = await storage.getUserPreferences(defaultUserId);
    res.json(preferences);
  } catch (error) {
    console.error("Error fetching user preferences:", error);
    res.status(500).json({ error: "Failed to fetch user preferences" });
  }
});

router.patch("/api/user/preferences", async (req, res) => {
  try {
    // For now, use anonymous user since we don't have auth
    const defaultUserId = "anonymous";
    const updates = req.body;
    
    const preferences = await storage.updateUserPreferences(defaultUserId, updates);
    res.json(preferences);
  } catch (error) {
    console.error("Error updating user preferences:", error);
    res.status(500).json({ error: "Failed to update user preferences" });
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Register all API routes
  app.use(router);

  const httpServer = createServer(app);
  return httpServer;
}
