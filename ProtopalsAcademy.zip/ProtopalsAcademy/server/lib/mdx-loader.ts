import fs from "fs/promises";
import path from "path";
import matter from "gray-matter";
import type { Tutorial, TutorialFrontmatter, Category } from "@shared/schema";
import { tutorialFrontmatterSchema } from "@shared/schema";

const TUTORIALS_DIR = path.join(process.cwd(), "content", "tutorials");

export class MDXLoader {
  private tutorialsCache: Map<string, Tutorial> = new Map();
  private categoriesCache: Map<string, Category> = new Map();
  private lastLoadTime = 0;
  private readonly CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

  async loadAllTutorials(): Promise<Tutorial[]> {
    // Check if we need to reload cache
    const now = Date.now();
    if (now - this.lastLoadTime < this.CACHE_DURATION && this.tutorialsCache.size > 0) {
      return Array.from(this.tutorialsCache.values());
    }

    try {
      // Ensure tutorials directory exists
      await this.ensureTutorialsDir();
      
      const files = await fs.readdir(TUTORIALS_DIR);
      const mdxFiles = files.filter(file => file.endsWith('.mdx'));
      
      const tutorials: Tutorial[] = [];
      
      for (const file of mdxFiles) {
        try {
          const tutorial = await this.loadTutorialFile(file);
          tutorials.push(tutorial);
          this.tutorialsCache.set(tutorial.slug, tutorial);
        } catch (error) {
          console.warn(`Failed to load tutorial ${file}:`, error);
        }
      }

      // Update categories cache
      await this.updateCategoriesFromTutorials(tutorials);
      
      this.lastLoadTime = now;
      return tutorials;
    } catch (error) {
      console.error("Failed to load tutorials:", error);
      return [];
    }
  }

  async getTutorialBySlug(slug: string): Promise<Tutorial | null> {
    // Try cache first
    if (this.tutorialsCache.has(slug)) {
      return this.tutorialsCache.get(slug)!;
    }

    try {
      const filePath = path.join(TUTORIALS_DIR, `${slug}.mdx`);
      const tutorial = await this.loadTutorialFromPath(filePath, slug);
      this.tutorialsCache.set(slug, tutorial);
      return tutorial;
    } catch (error) {
      return null;
    }
  }

  async getCategories(): Promise<Category[]> {
    // Ensure tutorials are loaded first to populate categories
    await this.loadAllTutorials();
    return Array.from(this.categoriesCache.values());
  }

  private async ensureTutorialsDir(): Promise<void> {
    try {
      await fs.access(TUTORIALS_DIR);
    } catch (error) {
      // Directory doesn't exist, create it with a sample tutorial
      await fs.mkdir(TUTORIALS_DIR, { recursive: true });
      await this.createSampleTutorial();
    }
  }

  private async createSampleTutorial(): Promise<void> {
    const sampleContent = `---
title: "Hand-Crank Single Cylinder Engine"
description: "Assemble a working single-cylinder engine to learn pistons, cranks, and bearings — fully 3D printable."
category: "Mechanical Builds"
difficulty: "Intermediate"
duration: "60 minutes"
age: "12+"
author: "Protopals Team"
date: "2025-01-15"
tags: ["3dprint", "engine", "mechanics"]
thumbnail: "/attached_assets/generated_images/Hand-crank_engine_tutorial_thumbnail_efbcafcf.png"
videoEmbed: "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
materials:
  - name: "3D printed cylinder"
    quantity: "1"
  - name: "M2 screws"
    quantity: "4"
  - name: "Bronze bushing"
    quantity: "1"
  - name: "Hand crank"
    quantity: "1"
  - name: "Washers and small bearings"
    quantity: "Set"
  - name: "Sandpaper"
    quantity: "1 sheet"
    optional: true
---

## Overview

Build a working single-cylinder engine with a hand crank to learn about pistons, connecting rods, crankshafts, bearings, and the basics of reciprocating motion. This tutorial is 60 minutes and best for ages 12 and up.

## What You'll Learn

- How pistons convert linear motion to rotational motion
- The role of connecting rods in mechanical systems
- Bearing types and their applications
- Basic principles of internal combustion engines

## Steps

### 1. Print all parts using the provided STL files

Use 0.2 mm layer height for stronger walls. The parts should fit together smoothly after printing.

> **Tip:** Check your printer's dimensional accuracy by printing the test piece first.

### 2. Clean up the parts

Lightly sand mating surfaces so they slide smoothly. Remove any support material carefully.

> **Warning:** Always wear safety glasses when using power tools or working with small parts.

### 3. Assemble the piston and pin

Insert the piston into the cylinder, and test fit the connecting rod. Everything should move freely.

### 4. Attach the connecting rod to the crankshaft

Use the provided screw and washer; check rotation for smooth operation.

### 5. Insert the bearing into the base

Fit the crank assembly and ensure proper alignment with minimal wobble.

### 6. Add the hand crank

Attach to the end of the crankshaft and test the complete motion.

### 7. Test and troubleshoot

If binding occurs, check for tight screws or misaligned parts; increase lubrication if necessary.

## Downloads

- [STL Files](/assets/models/engine-parts.zip)
- [Assembly Guide (PDF)](/assets/docs/engine-assembly.pdf)

## Next Steps

Try experimenting with different speeds and observe how the mechanical components work together. You can also modify the design to explore different piston configurations.

> **Success:** Congratulations! You've successfully built a working single-cylinder engine!
`;

    await fs.writeFile(
      path.join(TUTORIALS_DIR, "hand-crank-single-cylinder-engine.mdx"),
      sampleContent
    );
  }

  private async loadTutorialFile(filename: string): Promise<Tutorial> {
    const slug = filename.replace('.mdx', '');
    const filePath = path.join(TUTORIALS_DIR, filename);
    return this.loadTutorialFromPath(filePath, slug);
  }

  private async loadTutorialFromPath(filePath: string, slug: string): Promise<Tutorial> {
    const fileContent = await fs.readFile(filePath, 'utf-8');
    const { data, content } = matter(fileContent);
    
    // Validate frontmatter
    const frontmatter = tutorialFrontmatterSchema.parse(data);
    
    return {
      slug,
      frontmatter,
      content,
    };
  }

  private async updateCategoriesFromTutorials(tutorials: Tutorial[]): Promise<void> {
    const categoryMap = new Map<string, Category>();
    
    tutorials.forEach(tutorial => {
      const categoryName = tutorial.frontmatter.category;
      const categorySlug = this.slugify(categoryName);
      
      if (categoryMap.has(categorySlug)) {
        const existing = categoryMap.get(categorySlug)!;
        existing.tutorialCount++;
      } else {
        categoryMap.set(categorySlug, {
          name: categoryName,
          slug: categorySlug,
          description: this.getCategoryDescription(categoryName),
          tutorialCount: 1,
          icon: this.getCategoryIcon(categoryName),
        });
      }
    });

    this.categoriesCache = categoryMap;
  }

  private slugify(text: string): string {
    return text
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '');
  }

  private getCategoryDescription(category: string): string {
    const descriptions: Record<string, string> = {
      "Mechanical Builds": "Learn about gears, levers, and mechanical systems through hands-on building projects.",
      "Science Experiments": "Explore physics, chemistry, and biology concepts through fun and safe experiments.",
      "Electronics": "Get started with circuits, LEDs, sensors, and basic electronic components.",
      "Robotics Basics": "Build and program simple robots using Arduino and basic sensors.",
      "DIY Crafts": "Creative projects that combine art, science, and hands-on making.",
    };
    
    return descriptions[category] || `Explore ${category.toLowerCase()} through hands-on projects.`;
  }

  private getCategoryIcon(category: string): string {
    const icons: Record<string, string> = {
      "Mechanical Builds": "mechanical",
      "Science Experiments": "science", 
      "Electronics": "electronics",
      "Robotics Basics": "robotics",
      "DIY Crafts": "crafts",
    };
    
    return icons[category] || "tools";
  }
}

export const mdxLoader = new MDXLoader();