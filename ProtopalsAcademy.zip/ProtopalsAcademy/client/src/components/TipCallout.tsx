import { Card, CardContent } from "@/components/ui/card";
import { Lightbulb, AlertTriangle, Info, CheckCircle } from "lucide-react";

interface TipCalloutProps {
  type?: "tip" | "warning" | "info" | "success";
  title?: string;
  children: React.ReactNode;
  className?: string;
}

const typeConfig = {
  tip: {
    icon: Lightbulb,
    className: "bg-protopals-mint/20 border-protopals-orange/30",
    iconColor: "text-protopals-orange",
    titleColor: "text-protopals-orange",
  },
  warning: {
    icon: AlertTriangle,
    className: "bg-yellow-50 border-yellow-200 dark:bg-yellow-950/20 dark:border-yellow-800/30",
    iconColor: "text-yellow-600 dark:text-yellow-400",
    titleColor: "text-yellow-800 dark:text-yellow-200",
  },
  info: {
    icon: Info,
    className: "bg-blue-50 border-blue-200 dark:bg-blue-950/20 dark:border-blue-800/30",
    iconColor: "text-blue-600 dark:text-blue-400",
    titleColor: "text-blue-800 dark:text-blue-200",
  },
  success: {
    icon: CheckCircle,
    className: "bg-green-50 border-green-200 dark:bg-green-950/20 dark:border-green-800/30",
    iconColor: "text-green-600 dark:text-green-400",
    titleColor: "text-green-800 dark:text-green-200",
  },
};

export default function TipCallout({ type = "tip", title, children, className = "" }: TipCalloutProps) {
  const config = typeConfig[type];
  const Icon = config.icon;
  const defaultTitle = type.charAt(0).toUpperCase() + type.slice(1);

  return (
    <Card className={`${config.className} ${className}`} data-testid={`callout-${type}`}>
      <CardContent className="p-4">
        <div className="flex gap-3">
          <Icon className={`h-5 w-5 flex-shrink-0 mt-0.5 ${config.iconColor}`} />
          <div className="space-y-2">
            {(title || type === "tip") && (
              <h4 className={`font-semibold text-sm ${config.titleColor}`}>
                {title || defaultTitle}
              </h4>
            )}
            <div className="text-sm text-foreground leading-relaxed">
              {children}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}