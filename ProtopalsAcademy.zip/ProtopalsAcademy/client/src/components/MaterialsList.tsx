import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Package, RotateCcw } from "lucide-react";
import { getMaterialChecklist, updateMaterialChecklist } from "@/lib/storage";

interface Material {
  name: string;
  quantity?: string;
  optional?: boolean;
}

interface MaterialsListProps {
  materials: Material[];
  tutorialSlug: string;
  className?: string;
}

export default function MaterialsList({ materials, tutorialSlug, className = "" }: MaterialsListProps) {
  const [checkedMaterials, setCheckedMaterials] = useState<Record<string, boolean>>({});

  // Load checked state from storage
  useEffect(() => {
    const checklist = getMaterialChecklist(tutorialSlug);
    setCheckedMaterials(checklist);
  }, [tutorialSlug]);

  const toggleMaterial = (materialName: string, index: number) => {
    const materialId = `material-${index}`;
    const newState = !checkedMaterials[materialId];
    setCheckedMaterials(prev => ({
      ...prev,
      [materialId]: newState
    }));
    updateMaterialChecklist(tutorialSlug, materialId, newState);
  };

  const resetChecklist = () => {
    const resetState: Record<string, boolean> = {};
    materials.forEach((_, index) => {
      const materialId = `material-${index}`;
      resetState[materialId] = false;
      updateMaterialChecklist(tutorialSlug, materialId, false);
    });
    setCheckedMaterials(resetState);
  };

  const completedCount = Object.values(checkedMaterials).filter(Boolean).length;
  const totalCount = materials.length;
  const isComplete = completedCount === totalCount;

  return (
    <Card className={`${className}`} data-testid="materials-list">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-lg">
            <Package className="h-5 w-5 text-primary" />
            Materials Needed
          </CardTitle>
          <div className="flex items-center gap-2">
            <Badge variant={isComplete ? "default" : "secondary"} className="text-xs">
              {completedCount}/{totalCount}
            </Badge>
            {completedCount > 0 && (
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6"
                onClick={resetChecklist}
                title="Reset checklist"
                data-testid="button-reset-checklist"
              >
                <RotateCcw className="h-3 w-3" />
              </Button>
            )}
          </div>
        </div>
        
        {isComplete && (
          <div className="flex items-center gap-2 text-sm text-primary">
            <CheckCircle className="h-4 w-4" />
            All materials ready!
          </div>
        )}
      </CardHeader>

      <CardContent className="space-y-3">
        {materials.map((material, index) => {
          const materialId = `material-${index}`;
          const isChecked = checkedMaterials[materialId] || false;
          
          return (
            <div 
              key={materialId}
              className="flex items-start gap-3 group"
              data-testid={`material-item-${index}`}
            >
              <Checkbox
                id={materialId}
                checked={isChecked}
                onCheckedChange={() => toggleMaterial(material.name, index)}
                className="mt-0.5"
                data-testid={`checkbox-material-${index}`}
              />
              
              <label 
                htmlFor={materialId}
                className={`flex-1 text-sm cursor-pointer transition-colors ${
                  isChecked ? 'line-through text-muted-foreground' : 'text-foreground'
                }`}
              >
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="flex-1">
                    {material.name}
                    {material.quantity && ` (${material.quantity})`}
                  </span>
                  {material.optional && (
                    <Badge variant="outline" className="text-xs">
                      Optional
                    </Badge>
                  )}
                </div>
              </label>
            </div>
          );
        })}

        {materials.length === 0 && (
          <p className="text-muted-foreground text-sm text-center py-4">
            No materials needed for this tutorial.
          </p>
        )}
      </CardContent>
    </Card>
  );
}