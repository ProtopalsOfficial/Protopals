import { Badge } from "@/components/ui/badge";

interface DifficultyBadgeProps {
  difficulty: "Beginner" | "Intermediate" | "Advanced";
}

const difficultyConfig = {
  Beginner: {
    variant: "default" as const,
    className: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
  },
  Intermediate: {
    variant: "secondary" as const,
    className: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200",
  },
  Advanced: {
    variant: "destructive" as const,
    className: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
  },
};

export default function DifficultyBadge({ difficulty }: DifficultyBadgeProps) {
  const config = difficultyConfig[difficulty];
  
  return (
    <Badge 
      variant={config.variant}
      className={`text-xs font-medium ${config.className}`}
      data-testid={`badge-difficulty-${difficulty.toLowerCase()}`}
    >
      {difficulty}
    </Badge>
  );
}