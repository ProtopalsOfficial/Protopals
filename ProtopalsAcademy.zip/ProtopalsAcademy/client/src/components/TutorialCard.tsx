import { Link } from "wouter";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Clock, User, Heart } from "lucide-react";
import DifficultyBadge from "@/components/DifficultyBadge";

import type { Tutorial as TutorialType } from "@shared/schema";

export interface Tutorial {
  slug: string;
  frontmatter: TutorialType["frontmatter"];
  isFavorited?: boolean;
}

interface TutorialCardProps {
  tutorial: Tutorial;
  onToggleFavorite?: (slug: string) => void;
}

export default function TutorialCard({ tutorial, onToggleFavorite }: TutorialCardProps) {
  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (onToggleFavorite) {
      onToggleFavorite(tutorial.slug);
    }
  };

  return (
    <Card className="group overflow-hidden hover-elevate transition-all duration-200" data-testid={`card-tutorial-${tutorial.slug}`}>
      <Link href={`/tutorials/${tutorial.slug}`}>
        <div className="relative">
          <div className="aspect-video overflow-hidden bg-muted">
            <img 
              src={tutorial.frontmatter.thumbnail || '/api/placeholder/400/225'} 
              alt={tutorial.frontmatter.title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
              loading="lazy"
            />
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="absolute top-2 right-2 bg-background/80 backdrop-blur-sm hover:bg-background"
            onClick={handleFavoriteClick}
            data-testid={`button-favorite-${tutorial.slug}`}
          >
            <Heart className={`h-4 w-4 ${tutorial.isFavorited ? 'fill-primary text-primary' : 'text-muted-foreground'}`} />
          </Button>
        </div>
      </Link>

      <CardContent className="p-4">
        <div className="space-y-3">
          <div className="flex items-start justify-between gap-2">
            <Badge variant="secondary" className="text-xs font-medium" data-testid={`badge-category-${tutorial.frontmatter.category.toLowerCase().replace(' ', '-')}`}>
              {tutorial.frontmatter.category}
            </Badge>
            <DifficultyBadge difficulty={tutorial.frontmatter.difficulty} />
          </div>

          <Link href={`/tutorials/${tutorial.slug}`}>
            <h3 className="font-serif font-semibold text-lg leading-tight group-hover:text-primary transition-colors cursor-pointer" data-testid={`text-title-${tutorial.slug}`}>
              {tutorial.frontmatter.title}
            </h3>
          </Link>

          <p className="text-muted-foreground text-sm leading-relaxed line-clamp-2" data-testid={`text-description-${tutorial.slug}`}>
            {tutorial.frontmatter.description}
          </p>

          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <div className="flex items-center gap-1">
              <User className="h-3 w-3" />
              <span>{tutorial.frontmatter.author}</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1">
                <Clock className="h-3 w-3" />
                <span>{tutorial.frontmatter.duration}</span>
              </div>
              <Badge variant="outline" className="text-xs">
                {tutorial.frontmatter.age}
              </Badge>
            </div>
          </div>
        </div>
      </CardContent>

      <CardFooter className="p-4 pt-0">
        <div className="flex flex-wrap gap-1">
          {tutorial.frontmatter.tags.slice(0, 3).map((tag) => (
            <Badge key={tag} variant="outline" className="text-xs">
              #{tag}
            </Badge>
          ))}
          {tutorial.frontmatter.tags.length > 3 && (
            <Badge variant="outline" className="text-xs">
              +{tutorial.frontmatter.tags.length - 3}
            </Badge>
          )}
        </div>
      </CardFooter>
    </Card>
  );
}