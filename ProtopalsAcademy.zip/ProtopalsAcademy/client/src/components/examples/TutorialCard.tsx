import TutorialCard from '../TutorialCard';
import type { Tutorial } from '../TutorialCard';

export default function TutorialCardExample() {
  const sampleTutorial: Tutorial = {
    slug: "hand-crank-single-cylinder-engine",
    frontmatter: {
      title: "Hand-Crank Single Cylinder Engine",
      description: "Assemble a working single-cylinder engine to learn pistons, cranks, and bearings — fully 3D printable.",
      category: "Mechanical Builds",
      difficulty: "Intermediate",
      duration: "60 minutes",
      age: "12+",
      thumbnail: "/api/placeholder/400/225",
      author: "Protopals Team",
      date: "2025-01-15",
      tags: ["3dprint", "engine", "mechanics"],
      materials: [],
    },
    isFavorited: false,
  };

  const handleToggleFavorite = (slug: string) => {
    console.log('Toggle favorite for:', slug);
  };

  return (
    <div className="max-w-sm">
      <TutorialCard tutorial={sampleTutorial} onToggleFavorite={handleToggleFavorite} />
    </div>
  );
}