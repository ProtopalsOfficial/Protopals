import SearchBar from '../SearchBar';

export default function SearchBarExample() {
  const mockCategories = ["Mechanical Builds", "Science Experiments", "Electronics", "Robotics Basics", "DIY Crafts"];
  
  const mockFilters = {
    category: undefined,
    difficulty: undefined,
    sort: "newest",
  };

  const handleSearch = (query: string) => console.log('Search:', query);
  const handleCategoryFilter = (category: string | null) => console.log('Category filter:', category);
  const handleDifficultyFilter = (difficulty: string | null) => console.log('Difficulty filter:', difficulty);
  const handleSortChange = (sort: string) => console.log('Sort change:', sort);

  return (
    <div className="max-w-4xl mx-auto">
      <SearchBar
        onSearch={handleSearch}
        onCategoryFilter={handleCategoryFilter}
        onDifficultyFilter={handleDifficultyFilter}
        onSortChange={handleSortChange}
        activeFilters={mockFilters}
        categories={mockCategories}
      />
    </div>
  );
}