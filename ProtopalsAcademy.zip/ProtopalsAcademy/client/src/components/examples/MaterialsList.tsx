import MaterialsList from '../MaterialsList';

export default function MaterialsListExample() {
  const sampleMaterials = [
    { name: "3D printed cylinder", quantity: "1" },
    { name: "M2 screws", quantity: "4" },
    { name: "Bronze bushing", quantity: "1" },
    { name: "Hand crank", quantity: "1" },
    { name: "Sandpaper", quantity: "1 sheet", optional: true },
    { name: "Lubricant", optional: true },
  ];

  return (
    <div className="max-w-md">
      <MaterialsList 
        materials={sampleMaterials} 
        tutorialSlug="hand-crank-engine" 
      />
    </div>
  );
}