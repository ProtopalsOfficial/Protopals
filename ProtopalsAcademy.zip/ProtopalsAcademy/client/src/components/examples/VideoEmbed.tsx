import VideoEmbed from '../VideoEmbed';

export default function VideoEmbedExample() {
  return (
    <div className="max-w-2xl space-y-6">
      <div>
        <h3 className="text-lg font-semibold mb-2">YouTube Video</h3>
        <VideoEmbed
          videoUrl="https://www.youtube.com/watch?v=dQw4w9WgXcQ"
          title="Sample YouTube Video"
        />
      </div>
      
      <div>
        <h3 className="text-lg font-semibold mb-2">Instagram Post</h3>
        <VideoEmbed
          videoUrl="https://www.instagram.com/reel/ABC123DEF456/"
          title="Sample Instagram Reel"
        />
      </div>
    </div>
  );
}