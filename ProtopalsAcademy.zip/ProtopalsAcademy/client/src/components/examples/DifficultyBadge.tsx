import DifficultyBadge from '../DifficultyBadge';

export default function DifficultyBadgeExample() {
  return (
    <div className="flex gap-2">
      <DifficultyBadge difficulty="Beginner" />
      <DifficultyBadge difficulty="Intermediate" />
      <DifficultyBadge difficulty="Advanced" />
    </div>
  );
}