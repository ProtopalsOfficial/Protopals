import CategoryCard from '../CategoryCard';
import type { Category } from '../CategoryCard';

export default function CategoryCardExample() {
  const sampleCategory: Category = {
    name: "Mechanical Builds",
    description: "Learn about gears, levers, and mechanical systems through hands-on building projects.",
    slug: "mechanical-builds",
    tutorialCount: 12,
    icon: "mechanical",
  };

  return (
    <div className="max-w-sm">
      <CategoryCard category={sampleCategory} />
    </div>
  );
}