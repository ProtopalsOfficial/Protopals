import TipCallout from '../TipCallout';

export default function TipCalloutExample() {
  return (
    <div className="max-w-2xl space-y-4">
      <TipCallout type="tip" title="Pro Tip">
        Make sure to test fit all parts before final assembly to ensure smooth operation.
      </TipCallout>
      
      <TipCallout type="warning" title="Safety First">
        Always wear safety glasses when using power tools or working with small parts.
      </TipCallout>
      
      <TipCallout type="info">
        You can download the STL files for 3D printing from the resources section below.
      </TipCallout>
      
      <TipCallout type="success" title="Great Job!">
        You've successfully completed the mechanical assembly. Now let's test the movement.
      </TipCallout>
    </div>
  );
}