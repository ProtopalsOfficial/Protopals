import Layout from '../Layout';

export default function LayoutExample() {
  const handleSearch = (query: string) => {
    console.log('Search from layout:', query);
  };

  return (
    <Layout onSearch={handleSearch}>
      <div className="container mx-auto px-4 py-16 text-center">
        <h1 className="text-3xl font-bold mb-4">Layout Example</h1>
        <p className="text-muted-foreground">
          This shows the layout component with header and footer.
        </p>
      </div>
    </Layout>
  );
}