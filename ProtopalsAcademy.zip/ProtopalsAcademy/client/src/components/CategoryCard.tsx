import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight, Cog, FlaskConical, Zap, Wrench, Palette, Cpu } from "lucide-react";

export interface Category {
  name: string;
  description: string;
  slug: string;
  tutorialCount: number;
  icon: string;
}

interface CategoryCardProps {
  category: Category;
}

const iconMap = {
  mechanical: Cog,
  science: FlaskConical,
  electronics: Zap,
  robotics: Cpu,
  crafts: Palette,
  tools: Wrench,
};

export default function CategoryCard({ category }: CategoryCardProps) {
  const IconComponent = iconMap[category.icon as keyof typeof iconMap] || Cog;

  return (
    <Card className="group hover-elevate transition-all duration-200 h-full" data-testid={`card-category-${category.slug}`}>
      <CardContent className="p-6">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="p-3 rounded-lg bg-primary/10 text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
              <IconComponent className="h-6 w-6" />
            </div>
            <span className="text-sm text-muted-foreground font-medium">
              {category.tutorialCount} tutorial{category.tutorialCount !== 1 ? 's' : ''}
            </span>
          </div>

          <div className="space-y-2">
            <h3 className="font-serif font-semibold text-xl group-hover:text-primary transition-colors" data-testid={`text-category-${category.name.toLowerCase().replace(' ', '-')}`}>
              {category.name}
            </h3>
            <p className="text-muted-foreground text-sm leading-relaxed" data-testid={`text-description-${category.slug}`}>
              {category.description}
            </p>
          </div>

          <Link href={`/tutorials?category=${category.slug}`}>
            <Button 
              variant="ghost" 
              className="w-full justify-between group-hover:bg-primary group-hover:text-primary-foreground transition-colors"
              data-testid={`button-explore-${category.slug}`}
            >
              Explore Projects
              <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}