import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Youtube, Instagram, MessageSquare } from "lucide-react";

export default function Footer() {
  const footerLinks = {
    "Learn": [
      { name: "Tutorials", href: "/tutorials" },
      { name: "Categories", href: "/categories" },
      { name: "Beginner Projects", href: "/tutorials?difficulty=beginner" },
      { name: "Advanced Projects", href: "/tutorials?difficulty=advanced" },
    ],
    "Company": [
      { name: "About", href: "/about" },
      { name: "Mission", href: "/about#mission" },
      { name: "Contact", href: "/contact" },
      { name: "Community", href: "/community" },
    ],
    "Resources": [
      { name: "How to Contribute", href: "/contribute" },
      { name: "Community Showcase", href: "/showcase" },
      { name: "Downloads", href: "/downloads" },
      { name: "Help", href: "/help" },
    ],
  };

  const socialLinks = [
    { name: "YouTube", href: "https://youtube.com/protopals", icon: Youtube },
    { name: "Instagram", href: "https://instagram.com/protopals", icon: Instagram },
    { name: "Discord", href: "https://discord.gg/protopals", icon: MessageSquare },
  ];

  return (
    <footer className="border-t bg-muted/30 mt-16">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <div className="h-8 w-8 rounded-md bg-primary flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-lg">P</span>
              </div>
              <span className="font-serif font-bold text-xl text-foreground">Protopals</span>
            </div>
            <p className="text-muted-foreground text-sm max-w-xs">
              Making STEM learning tangible, approachable, and fun for everyone. 
              Prototype. Create. Play.
            </p>
            <div className="flex space-x-2">
              {socialLinks.map((social) => {
                const Icon = social.icon;
                return (
                  <Button
                    key={social.name}
                    variant="ghost"
                    size="icon"
                    asChild
                    data-testid={`link-social-${social.name.toLowerCase()}`}
                  >
                    <a href={social.href} target="_blank" rel="noopener noreferrer">
                      <Icon className="h-4 w-4" />
                      <span className="sr-only">{social.name}</span>
                    </a>
                  </Button>
                );
              })}
            </div>
          </div>

          {/* Footer Links */}
          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category} className="space-y-4">
              <h3 className="font-semibold text-foreground">{category}</h3>
              <ul className="space-y-2">
                {links.map((link) => (
                  <li key={link.name}>
                    <Link href={link.href} data-testid={`footer-link-${link.name.toLowerCase().replace(' ', '-')}`}>
                      <Button variant="ghost" className="h-auto p-0 text-muted-foreground hover:text-foreground text-left justify-start">
                        {link.name}
                      </Button>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="border-t mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-muted-foreground text-sm">
            © 2025 Protopals. Made with 💚 for curious minds.
          </p>
          <div className="flex space-x-4 mt-4 md:mt-0">
            <Button variant="ghost" className="h-auto p-0 text-muted-foreground hover:text-foreground text-sm">
              Privacy Policy
            </Button>
            <Button variant="ghost" className="h-auto p-0 text-muted-foreground hover:text-foreground text-sm">
              Terms of Use
            </Button>
          </div>
        </div>
      </div>
    </footer>
  );
}