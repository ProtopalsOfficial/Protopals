import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, X, Filter } from "lucide-react";

interface SearchBarProps {
  onSearch: (query: string) => void;
  onCategoryFilter: (category: string | null) => void;
  onDifficultyFilter: (difficulty: string | null) => void;
  onSortChange: (sort: string) => void;
  activeFilters: {
    category?: string;
    difficulty?: string;
    sort: string;
  };
  categories: string[];
}

export default function SearchBar({ 
  onSearch, 
  onCategoryFilter, 
  onDifficultyFilter, 
  onSortChange,
  activeFilters,
  categories 
}: SearchBarProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [showFilters, setShowFilters] = useState(false);

  // Debounced search
  useEffect(() => {
    const timer = setTimeout(() => {
      onSearch(searchQuery);
    }, 300);

    return () => clearTimeout(timer);
  }, [searchQuery, onSearch]);

  const difficulties = ["Beginner", "Intermediate", "Advanced"];
  const sortOptions = [
    { value: "newest", label: "Newest" },
    { value: "popular", label: "Most Popular" },
    { value: "difficulty", label: "Difficulty" },
    { value: "duration", label: "Duration" },
  ];

  const clearAllFilters = () => {
    onCategoryFilter(null);
    onDifficultyFilter(null);
    onSortChange("newest");
  };

  const hasActiveFilters = activeFilters.category || activeFilters.difficulty || activeFilters.sort !== "newest";

  return (
    <div className="space-y-4">
      {/* Search Input */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          type="search"
          placeholder="Search tutorials by title, tags, or description..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10 pr-12"
          data-testid="input-search-tutorials"
        />
        <Button
          variant="ghost"
          size="icon"
          className="absolute right-1 top-1/2 h-8 w-8 -translate-y-1/2"
          onClick={() => setShowFilters(!showFilters)}
          data-testid="button-toggle-filters"
        >
          <Filter className="h-4 w-4" />
        </Button>
      </div>

      {/* Filters */}
      {showFilters && (
        <div className="space-y-4 p-4 border rounded-lg bg-muted/30">
          <div className="flex flex-wrap gap-4">
            {/* Category Filter */}
            <div className="flex-1 min-w-48">
              <label className="text-sm font-medium text-foreground mb-2 block">Category</label>
              <Select 
                value={activeFilters.category || ""} 
                onValueChange={(value) => onCategoryFilter(value || null)}
              >
                <SelectTrigger data-testid="select-category">
                  <SelectValue placeholder="All categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All categories</SelectItem>
                  {categories.map((category) => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Difficulty Filter */}
            <div className="flex-1 min-w-48">
              <label className="text-sm font-medium text-foreground mb-2 block">Difficulty</label>
              <Select 
                value={activeFilters.difficulty || ""} 
                onValueChange={(value) => onDifficultyFilter(value || null)}
              >
                <SelectTrigger data-testid="select-difficulty">
                  <SelectValue placeholder="All levels" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All levels</SelectItem>
                  {difficulties.map((difficulty) => (
                    <SelectItem key={difficulty} value={difficulty}>
                      {difficulty}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Sort */}
            <div className="flex-1 min-w-48">
              <label className="text-sm font-medium text-foreground mb-2 block">Sort by</label>
              <Select 
                value={activeFilters.sort} 
                onValueChange={onSortChange}
              >
                <SelectTrigger data-testid="select-sort">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {sortOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Active Filters & Clear */}
          {hasActiveFilters && (
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-sm text-muted-foreground">Active filters:</span>
              {activeFilters.category && (
                <Badge variant="secondary" className="gap-1">
                  {activeFilters.category}
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-4 w-4 p-0 hover:bg-transparent"
                    onClick={() => onCategoryFilter(null)}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </Badge>
              )}
              {activeFilters.difficulty && (
                <Badge variant="secondary" className="gap-1">
                  {activeFilters.difficulty}
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-4 w-4 p-0 hover:bg-transparent"
                    onClick={() => onDifficultyFilter(null)}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </Badge>
              )}
              <Button
                variant="ghost"
                size="sm"
                onClick={clearAllFilters}
                className="h-6 px-2 text-xs"
                data-testid="button-clear-filters"
              >
                Clear all
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}