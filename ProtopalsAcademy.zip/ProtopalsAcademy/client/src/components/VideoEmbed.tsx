import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Play, AlertCircle } from "lucide-react";

interface VideoEmbedProps {
  videoUrl: string;
  title: string;
  thumbnail?: string;
  className?: string;
}

export default function VideoEmbed({ videoUrl, title, thumbnail, className = "" }: VideoEmbedProps) {
  const [isLoaded, setIsLoaded] = useState(false);
  const [hasError, setHasError] = useState(false);

  // Extract YouTube video ID
  const getYouTubeId = (url: string) => {
    const regex = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/;
    const match = url.match(regex);
    return match ? match[1] : null;
  };

  // Extract Instagram ID  
  const getInstagramId = (url: string) => {
    const regex = /instagram\.com\/(?:p|reel)\/([^\/\?]+)/;
    const match = url.match(regex);
    return match ? match[1] : null;
  };

  const youtubeId = getYouTubeId(videoUrl);
  const instagramId = getInstagramId(videoUrl);

  const handleLoad = () => {
    setIsLoaded(true);
    setHasError(false);
  };

  const handleError = () => {
    setHasError(true);
    setIsLoaded(false);
  };

  // YouTube embed
  if (youtubeId) {
    const embedUrl = `https://www.youtube.com/embed/${youtubeId}?rel=0`;
    const thumbnailUrl = thumbnail || `https://img.youtube.com/vi/${youtubeId}/maxresdefault.jpg`;

    return (
      <div className={`relative overflow-hidden rounded-lg bg-muted ${className}`} data-testid="video-embed-youtube">
        <div className="relative" style={{ paddingBottom: '56.25%', height: 0 }}>
          {!isLoaded && !hasError && (
            <div 
              className="absolute inset-0 bg-cover bg-center bg-no-repeat flex items-center justify-center cursor-pointer group hover-elevate"
              style={{ backgroundImage: `url(${thumbnailUrl})` }}
              onClick={() => setIsLoaded(true)}
            >
              <div className="absolute inset-0 bg-black/20"></div>
              <Button 
                size="lg" 
                className="relative z-10 bg-background/90 text-foreground hover:bg-background group-hover:scale-105 transition-transform"
                data-testid="button-play-video"
              >
                <Play className="h-6 w-6 mr-2" />
                Play Video
              </Button>
            </div>
          )}
          
          {isLoaded && !hasError && (
            <iframe
              src={embedUrl}
              className="absolute top-0 left-0 w-full h-full border-0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              title={title}
              onLoad={handleLoad}
              onError={handleError}
            />
          )}

          {hasError && (
            <div className="absolute inset-0 flex items-center justify-center bg-muted">
              <div className="text-center space-y-2">
                <AlertCircle className="h-8 w-8 text-muted-foreground mx-auto" />
                <p className="text-muted-foreground text-sm">Failed to load video</p>
                <Button variant="outline" size="sm" onClick={() => setIsLoaded(true)}>
                  Retry
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  // Instagram embed fallback
  if (instagramId) {
    return (
      <div className={`relative overflow-hidden rounded-lg bg-muted ${className}`} data-testid="video-embed-instagram">
        <div className="relative" style={{ paddingBottom: '56.25%', height: 0 }}>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center space-y-4">
              <p className="text-muted-foreground">View this tutorial on Instagram</p>
              <Button asChild>
                <a href={videoUrl} target="_blank" rel="noopener noreferrer">
                  Open Instagram Post
                </a>
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Fallback for unsupported video URLs
  return (
    <div className={`relative overflow-hidden rounded-lg bg-muted ${className}`} data-testid="video-embed-fallback">
      <div className="relative" style={{ paddingBottom: '56.25%', height: 0 }}>
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center space-y-4">
            <AlertCircle className="h-8 w-8 text-muted-foreground mx-auto" />
            <p className="text-muted-foreground">Unsupported video format</p>
            <Button variant="outline" asChild>
              <a href={videoUrl} target="_blank" rel="noopener noreferrer">
                View External Link
              </a>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}