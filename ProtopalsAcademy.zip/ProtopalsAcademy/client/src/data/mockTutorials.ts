import type { Tutorial } from "@/components/TutorialCard";

// TODO: remove mock functionality - replace with real data from MDX files
export const mockTutorials: Tutorial[] = [
  {
    slug: "hand-crank-single-cylinder-engine",
    title: "Hand-Crank Single Cylinder Engine", 
    description: "Assemble a working single-cylinder engine to learn pistons, cranks, and bearings — fully 3D printable.",
    category: "Mechanical Builds",
    difficulty: "Intermediate",
    duration: "60 minutes",
    age: "12+",
    thumbnail: "/attached_assets/generated_images/Hand-crank_engine_tutorial_thumbnail_efbcafcf.png",
    author: "Protopals Team",
    tags: ["3dprint", "engine", "mechanics"],
    isFavorited: false,
  },
  {
    slug: "intro-to-circuits-led-night-light",
    title: "Intro to Circuits — LED Night Light",
    description: "Simple electronics: breadboarding, LEDs, and resistors explained with a fun night-light build.",
    category: "Electronics",
    difficulty: "Beginner",
    duration: "30 minutes", 
    age: "10+",
    thumbnail: "/attached_assets/generated_images/LED_circuit_tutorial_thumbnail_a9d5e77d.png",
    author: "Protopals Team",
    tags: ["electronics", "led", "circuit"],
    isFavorited: false,
  },
  {
    slug: "paper-rocket-launcher",
    title: "Paper Rocket Launcher",
    description: "Learn thrust, pressure, and stability with an easy DIY paper rocket project.",
    category: "Science Experiments",
    difficulty: "Beginner",
    duration: "45 minutes",
    age: "8+",
    thumbnail: "/attached_assets/generated_images/Paper_rocket_tutorial_thumbnail_f2d674ad.png",
    author: "Protopals Team",
    tags: ["rockets", "physics", "diy"],
    isFavorited: false,
  },
  {
    slug: "simple-robot-car",
    title: "Simple Robot Car",
    description: "Build your first programmable robot using Arduino and basic sensors for obstacle avoidance.",
    category: "Robotics Basics",
    difficulty: "Advanced",
    duration: "90 minutes",
    age: "14+",
    thumbnail: "/api/placeholder/400/225",
    author: "Protopals Team",
    tags: ["arduino", "robotics", "programming"],
    isFavorited: false,
  },
  {
    slug: "diy-kaleidoscope",
    title: "DIY Kaleidoscope",
    description: "Create beautiful optical patterns while learning about mirrors, angles, and light reflection.",
    category: "DIY Crafts",
    difficulty: "Beginner",
    duration: "40 minutes",
    age: "8+",
    thumbnail: "/api/placeholder/400/225",
    author: "Protopals Team",
    tags: ["optics", "crafts", "mirrors"],
    isFavorited: false,
  },
  {
    slug: "hydraulic-arm",
    title: "Hydraulic Robotic Arm",
    description: "Understand fluid mechanics by building a hydraulic arm that can lift and move objects.",
    category: "Mechanical Builds",
    difficulty: "Advanced",
    duration: "75 minutes",
    age: "13+",
    thumbnail: "/api/placeholder/400/225",
    author: "Protopals Team",
    tags: ["hydraulics", "robotics", "mechanics"],
    isFavorited: false,
  },
];

export const mockCategories = [
  {
    name: "Mechanical Builds",
    description: "Learn about gears, levers, and mechanical systems through hands-on building projects.",
    slug: "mechanical-builds",
    tutorialCount: 2,
    icon: "mechanical",
  },
  {
    name: "Science Experiments",
    description: "Explore physics, chemistry, and biology concepts through fun and safe experiments.",
    slug: "science-experiments",
    tutorialCount: 1,
    icon: "science",
  },
  {
    name: "Electronics",
    description: "Get started with circuits, LEDs, sensors, and basic electronic components.",
    slug: "electronics",
    tutorialCount: 1,
    icon: "electronics",
  },
  {
    name: "Robotics Basics", 
    description: "Build and program simple robots using Arduino and basic sensors.",
    slug: "robotics-basics",
    tutorialCount: 1,
    icon: "robotics",
  },
  {
    name: "DIY Crafts",
    description: "Creative projects that combine art, science, and hands-on making.",
    slug: "diy-crafts",
    tutorialCount: 1,
    icon: "crafts",
  },
];

// TODO: remove mock functionality - replace with real MDX content
export const mockTutorialContent = {
  "hand-crank-single-cylinder-engine": {
    title: "Hand-Crank Single Cylinder Engine",
    date: "2025-01-15",
    author: "Protopals Team",
    category: "Mechanical Builds",
    tags: ["3dprint", "engine", "mechanics"],
    difficulty: "Intermediate" as const,
    age: "12+",
    duration: "60 minutes",
    thumbnail: "/attached_assets/generated_images/Hand-crank_engine_tutorial_thumbnail_efbcafcf.png",
    videoEmbed: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    materials: [
      { name: "3D printed cylinder", quantity: "1" },
      { name: "M2 screws", quantity: "4" },
      { name: "Bronze bushing", quantity: "1" },
      { name: "Hand crank", quantity: "1" },
      { name: "Washers and small bearings", quantity: "Set" },
      { name: "Sandpaper", quantity: "1 sheet", optional: true },
    ],
    content: `
## Overview

Build a working single-cylinder engine with a hand crank to learn about pistons, connecting rods, crankshafts, bearings, and the basics of reciprocating motion. This tutorial is 60 minutes and best for ages 12 and up.

## Materials

The materials list shows all the components you'll need. Make sure to gather everything before starting!

## Steps

### 1. Print all parts using the provided STL files
Use 0.2 mm layer height for stronger walls. The parts should fit together smoothly after printing.

### 2. Clean up the parts
Lightly sand mating surfaces so they slide smoothly. Remove any support material carefully.

### 3. Assemble the piston and pin
Insert the piston into the cylinder, and test fit the connecting rod. Everything should move freely.

### 4. Attach the connecting rod to the crankshaft
Use the provided screw and washer; check rotation for smooth operation.

### 5. Insert the bearing into the base
Fit the crank assembly and ensure proper alignment with minimal wobble.

### 6. Add the hand crank
Attach to the end of the crankshaft and test the complete motion.

### 7. Troubleshooting tips
If binding occurs, check for tight screws or misaligned parts; increase lubrication if necessary.

## Downloads

* STL files: [engine-piston.stl](/assets/models/engine-piston.stl)
* Assembly guide (PDF): [engine-assembly.pdf](/assets/docs/engine-assembly.pdf)
    `,
  },
};

export const getTutorialBySlug = (slug: string): Tutorial | undefined => {
  return mockTutorials.find(tutorial => tutorial.slug === slug);
};

export const getTutorialContent = (slug: string) => {
  return mockTutorialContent[slug as keyof typeof mockTutorialContent];
};

export const getFeaturedTutorials = (): Tutorial[] => {
  return mockTutorials.slice(0, 3);
};

export const getCategorySlugs = (): string[] => {
  return Array.from(new Set(mockTutorials.map(t => t.category)));
};