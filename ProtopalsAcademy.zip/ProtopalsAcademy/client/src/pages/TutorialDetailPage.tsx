import { useState, useEffect } from "react";
import { Link, useRoute } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import DifficultyBadge from "@/components/DifficultyBadge";
import VideoEmbed from "@/components/VideoEmbed";
import MaterialsList from "@/components/MaterialsList";
import TipCallout from "@/components/TipCallout";
import { useQuery } from "@tanstack/react-query";
import { apiClient } from "@/lib/api";
import type { Tutorial as TutorialType } from "@shared/schema";
import { ArrowLeft, Clock, User, Calendar, Download, Heart, Share2, CheckCircle2 } from "lucide-react";
import { isFavorite, toggleFavorite, isCompleted, markCompleted } from "@/lib/storage";

export default function TutorialDetailPage() {
  const [, params] = useRoute("/tutorials/:slug");
  const [isFavorited, setIsFavorited] = useState(false);
  const [isCompleteStatus, setIsCompleteStatus] = useState(false);
  
  const slug = params?.slug;
  
  const { data: tutorial, isLoading, error } = useQuery({
    queryKey: ['tutorial', slug],
    queryFn: () => slug ? apiClient.getTutorial(slug) : null,
    enabled: !!slug,
  });

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-16">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-muted rounded w-1/3" />
          <div className="h-12 bg-muted rounded w-2/3" />
          <div className="h-96 bg-muted rounded" />
        </div>
      </div>
    );
  }

  if (error || !tutorial) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h1 className="text-2xl font-bold mb-4">Tutorial Not Found</h1>
        <p className="text-muted-foreground mb-8">
          The tutorial you're looking for doesn't exist or has been moved.
        </p>
        <Link href="/tutorials">
          <Button variant="outline">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Tutorials
          </Button>
        </Link>
      </div>
    );
  }

  // Initialize state from localStorage
  useEffect(() => {
    if (slug) {
      setIsFavorited(isFavorite(slug));
      setIsCompleteStatus(isCompleted(slug));
    }
  }, [slug]);

  const handleToggleFavorite = () => {
    if (slug) {
      const newStatus = toggleFavorite(slug);
      setIsFavorited(newStatus);
    }
  };

  const handleMarkComplete = () => {
    if (slug) {
      markCompleted(slug);
      setIsCompleteStatus(true);
    }
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: tutorial.frontmatter.title,
        text: tutorial.frontmatter.description,
        url: window.location.href,
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      console.log('Link copied to clipboard');
    }
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="border-b bg-muted/30">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center gap-4 mb-4">
            <Link href="/tutorials">
              <Button variant="ghost" size="sm" data-testid="button-back-to-tutorials">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Tutorials
              </Button>
            </Link>
          </div>
          
          <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-2">
              <Badge variant="secondary">{tutorial.frontmatter.category}</Badge>
              <DifficultyBadge difficulty={tutorial.frontmatter.difficulty} />
              <Badge variant="outline">{tutorial.frontmatter.age}</Badge>
            </div>
            
            <h1 className="font-serif font-bold text-3xl lg:text-4xl text-foreground" data-testid="text-tutorial-title">
              {tutorial.frontmatter.title}
            </h1>
            
            <div className="flex items-center gap-6 text-sm text-muted-foreground">
              <div className="flex items-center gap-1">
                <User className="h-4 w-4" />
                <span>{tutorial.frontmatter.author}</span>
              </div>
              <div className="flex items-center gap-1">
                <Calendar className="h-4 w-4" />
                <span>{new Date(tutorial.frontmatter.date).toLocaleDateString()}</span>
              </div>
              <div className="flex items-center gap-1">
                <Clock className="h-4 w-4" />
                <span>{tutorial.frontmatter.duration}</span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Button
                variant={isFavorited ? "default" : "ghost"}
                size="sm"
                onClick={handleToggleFavorite}
                data-testid="button-toggle-favorite"
              >
                <Heart className={`mr-2 h-4 w-4 ${isFavorited ? 'fill-primary text-primary' : ''}`} />
                {isFavorited ? 'Favorited' : 'Add to Favorites'}
              </Button>
              <Button 
                variant={isCompleteStatus ? "default" : "ghost"} 
                size="sm" 
                onClick={handleMarkComplete}
                disabled={isCompleteStatus}
                data-testid="button-mark-complete"
              >
                <CheckCircle2 className={`mr-2 h-4 w-4 ${isCompleteStatus ? 'fill-primary text-primary' : ''}`} />
                {isCompleteStatus ? 'Completed' : 'Mark Complete'}
              </Button>
              <Button variant="ghost" size="sm" onClick={handleShare} data-testid="button-share">
                <Share2 className="mr-2 h-4 w-4" />
                Share
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="lg:grid lg:grid-cols-4 lg:gap-8">
          {/* Sidebar - Materials */}
          <div className="lg:col-span-1 space-y-6 mb-8 lg:mb-0">
            <MaterialsList 
              materials={tutorial.frontmatter.materials} 
              tutorialSlug={slug!}
            />
            
            {/* Download Links */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Download className="h-5 w-5 text-primary" />
                  Downloads
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button variant="outline" size="sm" className="w-full justify-start" data-testid="button-download-stl">
                  <Download className="mr-2 h-4 w-4" />
                  STL Files
                </Button>
                <Button variant="outline" size="sm" className="w-full justify-start" data-testid="button-download-pdf">
                  <Download className="mr-2 h-4 w-4" />
                  Assembly Guide (PDF)
                </Button>
              </CardContent>
            </Card>

            {/* Tags */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Tags</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {tutorial.frontmatter.tags.map((tag) => (
                    <Badge key={tag} variant="outline" className="text-xs">
                      #{tag}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3 space-y-8">
            {/* Video */}
            {tutorial.frontmatter.videoEmbed && (
              <VideoEmbed
                videoUrl={tutorial.frontmatter.videoEmbed}
                title={tutorial.frontmatter.title}
                className="shadow-lg"
              />
            )}

            {/* Content Body */}
            <div className="prose prose-lg max-w-none" data-testid="tutorial-content">
              {/* Overview */}
              <div className="space-y-4">
                <h2 className="font-serif font-bold text-2xl text-foreground">Overview</h2>
                <p className="text-lg text-muted-foreground leading-relaxed">
                  {tutorial.frontmatter.description}
                </p>
              </div>

              <Separator className="my-8" />

              {/* Tutorial Content */}
              <div 
                className="prose prose-lg max-w-none space-y-4"
                dangerouslySetInnerHTML={{ __html: tutorial.content }}
              />

              <Separator className="my-8" />

              {/* Success Message */}
              <TipCallout type="success" title="Congratulations!">
                You've successfully built a working single-cylinder engine! Try experimenting with different speeds and observe how the mechanical components work together.
              </TipCallout>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}