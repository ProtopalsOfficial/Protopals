import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import TutorialCard from "@/components/TutorialCard";
import type { Tutorial } from "@/components/TutorialCard";
import { ArrowRight, Play, Users, Lightbulb, Target } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { apiClient } from "@/lib/api";
import heroImage from "@assets/generated_images/STEM_education_hero_image_3390c9eb.png";

export default function HomePage() {
  const [favoritedTutorials, setFavoritedTutorials] = useState<Set<string>>(new Set());
  
  const { data: tutorialsResponse, isLoading } = useQuery({
    queryKey: ['tutorials', { sort: 'newest', page: 1 }],
    queryFn: () => apiClient.getTutorials({ sort: 'newest', page: 1 }),
  });
  
  const featuredTutorials = tutorialsResponse?.tutorials?.slice(0, 3) || [];

  const handleToggleFavorite = (slug: string) => {
    const newFavorites = new Set(favoritedTutorials);
    if (newFavorites.has(slug)) {
      newFavorites.delete(slug);
    } else {
      newFavorites.add(slug);
    }
    setFavoritedTutorials(newFavorites);
    console.log('Toggled favorite:', slug);
  };

  const tutorialsWithFavorites: Tutorial[] = featuredTutorials.map(tutorial => ({
    slug: tutorial.slug,
    frontmatter: tutorial.frontmatter,
    isFavorited: favoritedTutorials.has(tutorial.slug),
  }));

  return (
    <div className="space-y-16">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary/5 via-background to-accent/5">
        <div className="container mx-auto px-4 py-16 lg:py-24">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <h1 className="font-serif font-bold text-4xl lg:text-6xl leading-tight text-foreground" data-testid="text-hero-title">
                  Prototype. Create. Play.
                </h1>
                <p className="text-xl lg:text-2xl text-muted-foreground leading-relaxed">
                  Learn. Build. Explore. STEM made fun for everyone.
                </p>
              </div>
              
              <p className="text-lg text-muted-foreground leading-relaxed max-w-lg">
                Free hands-on tutorials and educational projects for ages 10-18. 
                Make learning tangible, approachable, and fun with Protopals.
              </p>

              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/tutorials">
                  <Button size="lg" className="bg-primary hover:bg-primary/90" data-testid="button-start-learning">
                    Start Learning
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
                <Link href="/categories">
                  <Button variant="outline" size="lg" data-testid="button-browse-categories">
                    Browse Categories
                  </Button>
                </Link>
              </div>
            </div>

            <div className="relative">
              <div className="aspect-video rounded-lg overflow-hidden bg-muted shadow-xl">
                <img 
                  src={heroImage} 
                  alt="Students engaged in hands-on STEM learning and prototyping"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-4 -right-4 bg-background p-4 rounded-lg shadow-lg border">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Play className="h-4 w-4 text-primary" />
                  <span>Interactive learning</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Tutorials */}
      <section className="container mx-auto px-4">
        <div className="space-y-8">
          <div className="text-center space-y-4">
            <h2 className="font-serif font-bold text-3xl lg:text-4xl text-foreground">
              Featured Projects
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Get started with these popular hands-on tutorials designed to spark curiosity and creativity.
            </p>
          </div>

          {isLoading ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-96 bg-muted animate-pulse rounded-lg" />
              ))}
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {tutorialsWithFavorites.map((tutorial) => (
                <TutorialCard 
                  key={tutorial.slug} 
                  tutorial={tutorial}
                  onToggleFavorite={handleToggleFavorite}
                />
              ))}
            </div>
          )}

          <div className="text-center">
            <Link href="/tutorials">
              <Button variant="outline" size="lg" data-testid="button-view-all-tutorials">
                View All Tutorials
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="bg-muted/30 py-16">
        <div className="container mx-auto px-4">
          <div className="text-center space-y-4 mb-12">
            <h2 className="font-serif font-bold text-3xl lg:text-4xl text-foreground">
              Why Protopals?
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              We believe in making STEM education accessible, engaging, and inspiring for all young minds.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                icon: Lightbulb,
                title: "Creativity",
                description: "Foster innovative thinking through hands-on projects and open-ended exploration.",
              },
              {
                icon: Target,
                title: "Curiosity", 
                description: "Encourage questions and discovery with engaging, real-world applications.",
              },
              {
                icon: Play,
                title: "Exploration",
                description: "Learn by doing with step-by-step tutorials that build confidence.",
              },
              {
                icon: Users,
                title: "Community",
                description: "Share your creations and inspire others in our growing maker community.",
              },
            ].map((value, index) => {
              const Icon = value.icon;
              return (
                <Card key={index} className="text-center hover-elevate transition-all duration-200">
                  <CardContent className="p-6 space-y-4">
                    <div className="w-12 h-12 rounded-lg bg-primary/10 text-primary flex items-center justify-center mx-auto">
                      <Icon className="h-6 w-6" />
                    </div>
                    <h3 className="font-serif font-semibold text-xl text-foreground">
                      {value.title}
                    </h3>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      {value.description}
                    </p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4 text-center">
        <div className="bg-gradient-to-r from-primary/10 via-accent/10 to-primary/10 rounded-2xl p-8 lg:p-12">
          <div className="space-y-6 max-w-2xl mx-auto">
            <h2 className="font-serif font-bold text-3xl lg:text-4xl text-foreground">
              Ready to Start Building?
            </h2>
            <p className="text-lg text-muted-foreground">
              Join thousands of students, teachers, and makers exploring STEM through hands-on projects.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/tutorials">
                <Button size="lg" className="bg-primary hover:bg-primary/90" data-testid="button-cta-explore">
                  Explore Tutorials
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Link href="/about">
                <Button variant="outline" size="lg" data-testid="button-learn-more">
                  Learn More
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}