import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import TutorialCard from "@/components/TutorialCard";
import type { Tutorial } from "@/components/TutorialCard";
import SearchBar from "@/components/SearchBar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { apiClient } from "@/lib/api";
import { ChevronLeft, ChevronRight } from "lucide-react";

const TUTORIALS_PER_PAGE = 12;

export default function TutorialsPage() {
  const [location, setLocation] = useLocation();
  const [favoritedTutorials, setFavoritedTutorials] = useState<Set<string>>(new Set());
  const [currentPage, setCurrentPage] = useState(1);
  
  // Get filters from URL params
  const urlParams = new URLSearchParams(location.split('?')[1] || '');
  const categoryFilter = urlParams.get('category');
  const difficultyFilter = urlParams.get('difficulty');
  const searchQuery = urlParams.get('search') || '';
  const sortBy = urlParams.get('sort') || 'newest';
  const urlPage = parseInt(urlParams.get('page') || '1');
  
  // Sync URL page with state on mount
  useEffect(() => {
    setCurrentPage(urlPage);
  }, [urlPage]);
  
  // Fetch categories and tutorials
  const { data: categories = [] } = useQuery({
    queryKey: ['categories'],
    queryFn: () => apiClient.getCategories(),
  });
  
  const { data: tutorialsResponse, isLoading } = useQuery({
    queryKey: ['tutorials', { search: searchQuery, category: categoryFilter, difficulty: difficultyFilter, sort: sortBy, page: currentPage }],
    queryFn: () => apiClient.getTutorials({
      search: searchQuery || undefined,
      category: categoryFilter || undefined, 
      difficulty: difficultyFilter || undefined,
      sort: sortBy,
      page: currentPage,
    }),
  });

  const tutorials = tutorialsResponse?.tutorials || [];
  const pagination = tutorialsResponse?.pagination;
  const totalPages = pagination?.totalPages || 1;

  const updateUrl = (params: Record<string, string | null>, resetPage = true) => {
    const newParams = new URLSearchParams(location.split('?')[1] || '');
    
    Object.entries(params).forEach(([key, value]) => {
      if (value) {
        newParams.set(key, value);
      } else {
        newParams.delete(key);
      }
    });
    
    // Reset to page 1 when filters change, otherwise preserve current page
    if (resetPage) {
      newParams.delete('page');
      setCurrentPage(1);
    } else {
      newParams.set('page', currentPage.toString());
    }

    const newUrl = newParams.toString() ? `/tutorials?${newParams.toString()}` : '/tutorials';
    setLocation(newUrl);
  };
  
  const updatePage = (page: number) => {
    setCurrentPage(page);
    const newParams = new URLSearchParams(location.split('?')[1] || '');
    if (page > 1) {
      newParams.set('page', page.toString());
    } else {
      newParams.delete('page');
    }
    const newUrl = newParams.toString() ? `/tutorials?${newParams.toString()}` : '/tutorials';
    setLocation(newUrl);
  };

  const handleSearch = (query: string) => {
    updateUrl({ search: query || null });
  };

  const handleCategoryFilter = (category: string | null) => {
    updateUrl({ category });
  };

  const handleDifficultyFilter = (difficulty: string | null) => {
    updateUrl({ difficulty });
  };

  const handleSortChange = (sort: string) => {
    updateUrl({ sort: sort !== 'newest' ? sort : null });
  };

  const handleToggleFavorite = (slug: string) => {
    const newFavorites = new Set(favoritedTutorials);
    if (newFavorites.has(slug)) {
      newFavorites.delete(slug);
    } else {
      newFavorites.add(slug);
    }
    setFavoritedTutorials(newFavorites);
    console.log('Toggled favorite:', slug);
  };

  const tutorialsWithFavorites: Tutorial[] = tutorials.map(tutorial => ({
    slug: tutorial.slug,
    frontmatter: tutorial.frontmatter,
    isFavorited: favoritedTutorials.has(tutorial.slug),
  }));
  
  const categoryNames = categories.map(cat => cat.name);

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="space-y-8">
        {/* Header */}
        <div className="space-y-4">
          <h1 className="font-serif font-bold text-3xl lg:text-4xl text-foreground" data-testid="text-page-title">
            STEM Tutorials
          </h1>
          <p className="text-lg text-muted-foreground">
            Discover hands-on projects and step-by-step tutorials to build, learn, and explore.
          </p>
        </div>

        {/* Search and Filters */}
        <SearchBar
          onSearch={handleSearch}
          onCategoryFilter={handleCategoryFilter}
          onDifficultyFilter={handleDifficultyFilter}
          onSortChange={handleSortChange}
          activeFilters={{
            category: categoryFilter || undefined,
            difficulty: difficultyFilter || undefined,
            sort: sortBy,
          }}
          categories={categoryNames}
        />

        {/* Results Info */}
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-4">
            <p className="text-muted-foreground" data-testid="text-results-count">
              {pagination?.totalCount || 0} tutorial{(pagination?.totalCount || 0) !== 1 ? 's' : ''} found
            </p>
            
            {/* Active filters display */}
            <div className="flex gap-2 flex-wrap">
              {categoryFilter && (
                <Badge variant="secondary" data-testid={`active-filter-category-${categoryFilter.toLowerCase().replace(' ', '-')}`}>
                  {categoryFilter}
                </Badge>
              )}
              {difficultyFilter && (
                <Badge variant="secondary" data-testid={`active-filter-difficulty-${difficultyFilter.toLowerCase()}`}>
                  {difficultyFilter}
                </Badge>
              )}
              {searchQuery && (
                <Badge variant="secondary" data-testid="active-filter-search">
                  "{searchQuery}"
                </Badge>
              )}
            </div>
          </div>

          {/* Pagination info */}
          {totalPages > 1 && (
            <p className="text-sm text-muted-foreground">
              Page {pagination?.currentPage || 1} of {totalPages}
            </p>
          )}
        </div>

        {/* Tutorials Grid */}
        {isLoading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="h-96 bg-muted animate-pulse rounded-lg" />
            ))}
          </div>
        ) : tutorialsWithFavorites.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6" data-testid="tutorials-grid">
            {tutorialsWithFavorites.map((tutorial) => (
              <TutorialCard 
                key={tutorial.slug} 
                tutorial={tutorial}
                onToggleFavorite={handleToggleFavorite}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-12" data-testid="no-results">
            <p className="text-lg text-muted-foreground mb-4">
              No tutorials found matching your criteria.
            </p>
            <Button 
              variant="outline" 
              onClick={() => {
                setLocation('/tutorials');
              }}
              data-testid="button-clear-filters"
            >
              Clear all filters
            </Button>
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex justify-center items-center gap-2" data-testid="pagination">
            <Button
              variant="outline"
              size="icon"
              disabled={!pagination?.hasPrev}
              onClick={() => updatePage(currentPage - 1)}
              data-testid="button-prev-page"
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            
            <div className="flex gap-1">
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                <Button
                  key={page}
                  variant={(pagination?.currentPage || 1) === page ? "default" : "outline"}
                  size="icon"
                  onClick={() => updatePage(page)}
                  data-testid={`button-page-${page}`}
                >
                  {page}
                </Button>
              ))}
            </div>

            <Button
              variant="outline"
              size="icon"
              disabled={!pagination?.hasNext}
              onClick={() => updatePage(currentPage + 1)}
              data-testid="button-next-page"
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}