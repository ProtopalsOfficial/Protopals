import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Lightbulb, Users, Target, Heart, ArrowRight, Camera } from "lucide-react";

export default function AboutPage() {
  const coreValues = [
    {
      icon: Lightbulb,
      title: "Creativity",
      description: "We foster innovative thinking through hands-on projects that encourage experimentation and creative problem-solving.",
    },
    {
      icon: Target,
      title: "Curiosity",
      description: "We inspire questions and discovery by connecting learning to real-world applications that matter to young minds.",
    },
    {
      icon: Users,
      title: "Exploration",
      description: "We believe learning happens best through doing, with step-by-step guidance that builds confidence and skills.",
    },
    {
      icon: Heart,
      title: "Community",
      description: "We create a supportive space where makers can share their creations, learn from each other, and inspire the next generation.",
    },
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="space-y-16">
        {/* Hero Section */}
        <div className="text-center space-y-6 max-w-4xl mx-auto">
          <h1 className="font-serif font-bold text-3xl lg:text-4xl text-foreground" data-testid="text-page-title">
            About Protopals
          </h1>
          
          <div className="space-y-6">
            <div className="text-xl lg:text-2xl text-primary font-medium leading-relaxed">
              "Protopals exists to inspire creativity, learning, and innovation in STEM through hands-on tutorials and playful projects."
            </div>
            
            <p className="text-lg text-muted-foreground leading-relaxed">
              We make learning tangible, approachable, and fun by providing free educational resources 
              that bridge the gap between theoretical knowledge and practical application.
            </p>
          </div>
        </div>

        {/* Mission Statement */}
        <div className="bg-gradient-to-br from-primary/5 via-background to-accent/5 rounded-2xl p-8 lg:p-12">
          <div className="text-center space-y-6 max-w-3xl mx-auto">
            <h2 className="font-serif font-bold text-2xl lg:text-3xl text-foreground">
              Our Mission
            </h2>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Every young person deserves access to engaging, hands-on STEM education. 
              We create free tutorials and projects that make complex concepts accessible through 
              practical building experiences, fostering the next generation of innovators, 
              creators, and problem-solvers.
            </p>
          </div>
        </div>

        {/* Core Values */}
        <div className="space-y-8">
          <div className="text-center space-y-4">
            <h2 className="font-serif font-bold text-2xl lg:text-3xl text-foreground">
              Our Core Values
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              These principles guide everything we do, from designing tutorials to building our community.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {coreValues.map((value, index) => {
              const Icon = value.icon;
              return (
                <Card key={index} className="hover-elevate transition-all duration-200" data-testid={`value-card-${value.title.toLowerCase()}`}>
                  <CardContent className="p-6 space-y-4">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
                        <Icon className="h-6 w-6" />
                      </div>
                      <h3 className="font-serif font-semibold text-xl text-foreground">
                        {value.title}
                      </h3>
                    </div>
                    <p className="text-muted-foreground leading-relaxed">
                      {value.description}
                    </p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* How to Contribute */}
        <div className="bg-muted/30 rounded-2xl p-8 lg:p-12">
          <div className="grid lg:grid-cols-2 gap-8 items-center">
            <div className="space-y-6">
              <h2 className="font-serif font-bold text-2xl lg:text-3xl text-foreground">
                How to Contribute
              </h2>
              <div className="space-y-4">
                <p className="text-lg text-muted-foreground leading-relaxed">
                  Protopals thrives thanks to our amazing community of makers, educators, and students. 
                  There are many ways to get involved and help us grow.
                </p>
                
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <Camera className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-semibold text-foreground">Share Your Builds</h4>
                      <p className="text-sm text-muted-foreground">
                        Submit photos of your completed projects to our Community Showcase
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <Users className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-semibold text-foreground">Join the Discussion</h4>
                      <p className="text-sm text-muted-foreground">
                        Connect with other makers on our Discord and social channels
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <Lightbulb className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-semibold text-foreground">Suggest Projects</h4>
                      <p className="text-sm text-muted-foreground">
                        Have an idea for a tutorial? We'd love to hear from you
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/community">
                  <Button size="lg" data-testid="button-join-community">
                    Join Community
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
                <Button variant="outline" size="lg" data-testid="button-contact-us">
                  Contact Us
                </Button>
              </div>
            </div>
            
            <div className="relative">
              <div className="aspect-square rounded-xl bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
                <div className="text-center space-y-4">
                  <Camera className="h-16 w-16 text-primary mx-auto" />
                  <p className="text-lg font-medium text-foreground">
                    Community Showcase
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Coming Soon
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Team/Contact Section */}
        <div className="text-center space-y-6">
          <h2 className="font-serif font-bold text-2xl lg:text-3xl text-foreground">
            Get in Touch
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Questions, suggestions, or just want to say hello? 
            We'd love to hear from you and learn about your STEM journey.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" data-testid="button-contact-email">
              Send us an Email
            </Button>
            <Link href="/tutorials">
              <Button variant="outline" size="lg" data-testid="button-start-exploring">
                Start Exploring
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}