import CategoryCard from "@/components/CategoryCard";
import { useQuery } from "@tanstack/react-query";
import { apiClient } from "@/lib/api";

export default function CategoriesPage() {
  const { data: categories = [], isLoading } = useQuery({
    queryKey: ['categories'],
    queryFn: () => apiClient.getCategories(),
  });

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="font-serif font-bold text-3xl lg:text-4xl text-foreground" data-testid="text-page-title">
            Explore Categories
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Discover different areas of STEM through hands-on projects designed to inspire creativity and learning.
          </p>
        </div>

        {/* Categories Grid */}
        {isLoading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="h-48 bg-muted animate-pulse rounded-lg" />
            ))}
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6" data-testid="categories-grid">
            {categories.map((category) => (
              <CategoryCard key={category.slug} category={category} />
            ))}
          </div>
        )}

        {/* Additional Info */}
        <div className="text-center space-y-4 pt-8">
          <h2 className="font-serif font-semibold text-2xl text-foreground">
            Can't find what you're looking for?
          </h2>
          <p className="text-muted-foreground max-w-lg mx-auto">
            We're constantly adding new categories and tutorials. 
            Follow our social channels to stay updated with the latest projects.
          </p>
        </div>
      </div>
    </div>
  );
}