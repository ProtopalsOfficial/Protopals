import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";

// Layout
import Layout from "@/components/Layout";

// Pages
import HomePage from "@/pages/HomePage";
import TutorialsPage from "@/pages/TutorialsPage";
import TutorialDetailPage from "@/pages/TutorialDetailPage";
import CategoriesPage from "@/pages/CategoriesPage";
import AboutPage from "@/pages/AboutPage";
import NotFound from "@/pages/not-found";

function Router() {
  const handleGlobalSearch = (query: string) => {
    // TODO: implement global search functionality
    console.log('Global search:', query);
    // For now, redirect to tutorials page with search query
    window.location.href = `/tutorials?search=${encodeURIComponent(query)}`;
  };

  return (
    <Layout onSearch={handleGlobalSearch}>
      <Switch>
        <Route path="/" component={HomePage} />
        <Route path="/tutorials" component={TutorialsPage} />
        <Route path="/tutorials/:slug" component={TutorialDetailPage} />
        <Route path="/categories" component={CategoriesPage} />
        <Route path="/about" component={AboutPage} />
        {/* Fallback to 404 */}
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;