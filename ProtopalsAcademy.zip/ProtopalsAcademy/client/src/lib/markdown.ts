// Simple markdown to HTML conversion for tutorial content
// Since we're using server-side MDX parsing, this handles basic markdown rendering

export function renderMarkdown(content: string): string {
  return content
    // Headers
    .replace(/^### (.*$)/gim, '<h3 class="font-semibold text-xl text-foreground flex items-center gap-3 mt-6 mb-3">$1</h3>')
    .replace(/^## (.*$)/gim, '<h2 class="font-serif font-bold text-2xl text-foreground mt-8 mb-4">$1</h2>')
    .replace(/^# (.*$)/gim, '<h1 class="font-serif font-bold text-3xl text-foreground mt-8 mb-6">$1</h1>')
    
    // Blockquotes for tips
    .replace(/^> \*\*(.*?)\*\*\s+(.*$)/gim, '<div class="my-4 p-4 border-l-4 border-primary/30 bg-muted/30 rounded-r-lg"><strong class="text-primary">$1</strong><br />$2</div>')
    .replace(/^> (.*$)/gim, '<blockquote class="border-l-4 border-muted-foreground/30 pl-4 italic text-muted-foreground my-4">$1</blockquote>')
    
    // Bold and Italic
    .replace(/\*\*(.*?)\*\*/g, '<strong class="font-semibold text-foreground">$1</strong>')
    .replace(/\*(.*?)\*/g, '<em class="italic">$1</em>')
    
    // Code
    .replace(/`(.*?)`/g, '<code class="bg-muted px-1 py-0.5 rounded text-sm font-mono">$1</code>')
    
    // Links
    .replace(/\[(.*?)\]\((.*?)\)/g, '<a href="$2" class="text-primary hover:underline">$1</a>')
    
    // Lists
    .replace(/^\- (.*$)/gim, '<li class="ml-4">• $1</li>')
    
    // Paragraphs
    .replace(/\n\n/g, '</p><p class="text-muted-foreground leading-relaxed mb-4">')
    .replace(/^(.+)$/gm, function(match, p1) {
      // Don't wrap lines that are already HTML elements
      if (p1.match(/^<(h[1-6]|div|blockquote|li|ul|ol)/)) {
        return p1;
      }
      return '<p class="text-muted-foreground leading-relaxed mb-4">' + p1 + '</p>';
    })
    
    // Clean up empty paragraphs and multiple closing tags
    .replace(/<p class="[^"]*"><\/p>/g, '')
    .replace(/<\/p><p class="[^"]*">$/g, '');
}