// Client-side storage utilities for user preferences and favorites

export interface UserPreferences {
  theme: 'light' | 'dark' | 'auto';
  favoriteCategories: string[];
  preferredDifficulty: string[];
  completedTutorials: string[];
  favoriteTutorials: string[];
  materialChecklists: Record<string, Record<string, boolean>>; // tutorial slug -> material id -> checked
}

const STORAGE_KEY = 'protopals-preferences';

// Default preferences
const defaultPreferences: UserPreferences = {
  theme: 'auto',
  favoriteCategories: [],
  preferredDifficulty: [],
  completedTutorials: [],
  favoriteTutorials: [],
  materialChecklists: {},
};

// Get preferences from localStorage
export function getPreferences(): UserPreferences {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) return defaultPreferences;
    
    const parsed = JSON.parse(stored);
    return { ...defaultPreferences, ...parsed };
  } catch (error) {
    console.warn('Failed to load preferences from localStorage:', error);
    return defaultPreferences;
  }
}

// Save preferences to localStorage
export function savePreferences(preferences: Partial<UserPreferences>): void {
  try {
    const current = getPreferences();
    const updated = { ...current, ...preferences };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  } catch (error) {
    console.warn('Failed to save preferences to localStorage:', error);
  }
}

// Toggle tutorial favorite status
export function toggleFavorite(tutorialSlug: string): boolean {
  const preferences = getPreferences();
  const favorites = [...preferences.favoriteTutorials];
  const index = favorites.indexOf(tutorialSlug);
  
  if (index >= 0) {
    favorites.splice(index, 1);
  } else {
    favorites.push(tutorialSlug);
  }
  
  savePreferences({ favoriteTutorials: favorites });
  return index < 0; // Return new favorite status
}

// Check if tutorial is favorited
export function isFavorite(tutorialSlug: string): boolean {
  const preferences = getPreferences();
  return preferences.favoriteTutorials.includes(tutorialSlug);
}

// Mark tutorial as completed
export function markCompleted(tutorialSlug: string): void {
  const preferences = getPreferences();
  const completed = [...preferences.completedTutorials];
  
  if (!completed.includes(tutorialSlug)) {
    completed.push(tutorialSlug);
    savePreferences({ completedTutorials: completed });
  }
}

// Check if tutorial is completed
export function isCompleted(tutorialSlug: string): boolean {
  const preferences = getPreferences();
  return preferences.completedTutorials.includes(tutorialSlug);
}

// Update material checklist for a tutorial
export function updateMaterialChecklist(tutorialSlug: string, materialId: string, checked: boolean): void {
  const preferences = getPreferences();
  const checklists = { ...preferences.materialChecklists };
  
  if (!checklists[tutorialSlug]) {
    checklists[tutorialSlug] = {};
  }
  
  checklists[tutorialSlug][materialId] = checked;
  savePreferences({ materialChecklists: checklists });
}

// Get material checklist for a tutorial
export function getMaterialChecklist(tutorialSlug: string): Record<string, boolean> {
  const preferences = getPreferences();
  return preferences.materialChecklists[tutorialSlug] || {};
}

// Get completion percentage for materials checklist
export function getMaterialsProgress(tutorialSlug: string, totalMaterials: number): number {
  if (totalMaterials === 0) return 100;
  
  const checklist = getMaterialChecklist(tutorialSlug);
  const completedCount = Object.values(checklist).filter(Boolean).length;
  return Math.round((completedCount / totalMaterials) * 100);
}