import type { Tutorial, Category, SearchFilters } from "@shared/schema";

export interface TutorialsResponse {
  tutorials: Tutorial[];
  pagination: {
    currentPage: number;
    totalPages: number;
    totalCount: number;
    hasNext: boolean;
    hasPrev: boolean;
  };
  filters: SearchFilters;
}

export interface SearchResponse {
  tutorials: Tutorial[];
  query: string;
}

export interface CategoryTutorialsResponse {
  category: Category;
  tutorials: Tutorial[];
}

class ApiClient {
  private baseUrl = "/api";

  async getTutorials(params?: {
    search?: string;
    category?: string;
    difficulty?: string;
    sort?: string;
    page?: number;
  }): Promise<TutorialsResponse> {
    const searchParams = new URLSearchParams();
    
    if (params?.search) searchParams.set("search", params.search);
    if (params?.category) searchParams.set("category", params.category);
    if (params?.difficulty) searchParams.set("difficulty", params.difficulty);
    if (params?.sort) searchParams.set("sort", params.sort);
    if (params?.page) searchParams.set("page", params.page.toString());

    const url = `${this.baseUrl}/tutorials${searchParams.toString() ? `?${searchParams.toString()}` : ""}`;
    const response = await fetch(url);
    
    if (!response.ok) {
      throw new Error(`Failed to fetch tutorials: ${response.statusText}`);
    }
    
    return response.json();
  }

  async getTutorial(slug: string): Promise<Tutorial> {
    const response = await fetch(`${this.baseUrl}/tutorials/${slug}`);
    
    if (!response.ok) {
      if (response.status === 404) {
        throw new Error("Tutorial not found");
      }
      throw new Error(`Failed to fetch tutorial: ${response.statusText}`);
    }
    
    return response.json();
  }

  async getCategories(): Promise<Category[]> {
    const response = await fetch(`${this.baseUrl}/categories`);
    
    if (!response.ok) {
      throw new Error(`Failed to fetch categories: ${response.statusText}`);
    }
    
    return response.json();
  }

  async getCategoryTutorials(slug: string): Promise<CategoryTutorialsResponse> {
    const response = await fetch(`${this.baseUrl}/categories/${slug}/tutorials`);
    
    if (!response.ok) {
      if (response.status === 404) {
        throw new Error("Category not found");
      }
      throw new Error(`Failed to fetch category tutorials: ${response.statusText}`);
    }
    
    return response.json();
  }

  async searchTutorials(query: string): Promise<SearchResponse> {
    const searchParams = new URLSearchParams({ q: query });
    const response = await fetch(`${this.baseUrl}/search?${searchParams.toString()}`);
    
    if (!response.ok) {
      throw new Error(`Failed to search tutorials: ${response.statusText}`);
    }
    
    return response.json();
  }
}

export const apiClient = new ApiClient();