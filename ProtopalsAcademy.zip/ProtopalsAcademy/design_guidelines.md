# Protopals Educational Website Design Guidelines

## Design Approach
**Reference-Based Approach**: Drawing inspiration from modern educational platforms like Khan Academy and Coursera, with the playful aesthetic of platforms like Scratch or Code.org. The design balances educational credibility with approachable, fun elements.

## Core Design Elements

### A. Color Palette
**Primary Colors:**
- Green primary: 142 71% 45% (forest green for trust and growth)
- Green secondary: 142 45% 65% (lighter green for backgrounds)

**Accent Colors:**
- Mint accent: 160 65% 85% (soft mint for highlights)
- Orange highlight: 25 85% 60% (energetic orange for CTAs and important elements)

**Neutral Colors:**
- Dark mode: 220 15% 12% (deep blue-gray background)
- Light mode: 0 0% 98% (warm white background)
- Text primary: 220 25% 15% (dark blue-gray)
- Text secondary: 220 15% 45% (medium gray)

### B. Typography
**Font Stack:**
- Primary: Inter (clean, readable sans-serif via Google Fonts)
- Headings: Poppins (friendly, rounded headers via Google Fonts)
- Code: JetBrains Mono (for any code snippets)

**Typography Scale:**
- Hero headings: 3xl-4xl weight-700
- Section headings: xl-2xl weight-600
- Body text: base-lg weight-400
- Captions: sm weight-400

### C. Layout System
**Spacing Primitives:** Tailwind units of 2, 4, 6, 8, 12, 16
- Micro spacing: p-2, m-2 (8px)
- Standard spacing: p-4, m-4 (16px)
- Section spacing: p-8, m-8 (32px)
- Large spacing: p-16 (64px for major sections)

**Grid System:**
- Mobile: Single column with p-4 margins
- Tablet: 2-3 column grid with p-6 margins
- Desktop: Up to 4 column grid with p-8 margins

### D. Component Library

**Navigation:**
- Clean header with logo, main nav links, and hamburger menu (mobile)
- Sticky navigation with subtle shadow on scroll
- Footer with organized link sections and social icons

**Cards:**
- Tutorial cards with rounded corners (rounded-lg)
- Hover effects with subtle scale and shadow
- Category badges with green/mint color coding
- Difficulty indicators with visual icons

**Buttons:**
- Primary: Green background with white text
- Secondary: Outline style with green border
- CTA: Orange background for high-priority actions
- When placed over images: Blurred background with outline variant

**Forms:**
- Search bar with subtle shadows and green focus states
- Filter toggles with checkbox-style design
- Consistent padding and border radius across inputs

**Content Display:**
- MDX content with proper typography hierarchy
- Code blocks with syntax highlighting
- Video embed containers with responsive aspect ratios
- Material lists with checkable items

### E. Interactions & Animations
**Minimal Animation Philosophy:**
- Subtle hover states on interactive elements
- Smooth page transitions (200-300ms)
- Loading states for search and content
- No distracting animations that detract from learning

## Images
**Hero Section:**
- Large hero image showcasing hands-on STEM activities or prototyping
- Children or teens engaged in building/creating projects
- Bright, energetic lighting with green/natural tones
- Image should convey innovation, creativity, and learning

**Tutorial Cards:**
- Thumbnail images for each tutorial showing the final project
- Clear, well-lit photos of completed prototypes
- Consistent aspect ratio (16:9 or 4:3)
- Should inspire curiosity and excitement

**Category Pages:**
- Icon-based illustrations for different STEM categories
- Simple, flat design style with green color scheme
- Recognizable symbols (gears for engineering, beakers for chemistry, etc.)

## Key Design Principles
1. **Educational Clarity**: Content hierarchy that guides learning progression
2. **Playful Professionalism**: Serious about education, fun in presentation
3. **Accessibility First**: WCAG AA compliance with proper contrast and navigation
4. **Mobile Excellence**: Mobile-first design ensuring great experience on all devices
5. **Green Growth**: Color psychology supporting learning and environmental consciousness

## Responsive Behavior
- Mobile: Stack content vertically, prioritize touch targets
- Tablet: 2-column layouts with comfortable spacing
- Desktop: Rich multi-column layouts with sidebar navigation
- All breakpoints maintain readability and usability