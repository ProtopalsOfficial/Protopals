import { z } from "zod";

// Tutorial schemas
export const tutorialFrontmatterSchema = z.object({
  title: z.string(),
  description: z.string(),
  category: z.string(),
  difficulty: z.enum(["Beginner", "Intermediate", "Advanced"]),
  duration: z.string(),
  age: z.string(),
  author: z.string(),
  date: z.string(),
  tags: z.array(z.string()),
  thumbnail: z.string().optional(),
  videoEmbed: z.string().optional(),
  materials: z.array(z.object({
    name: z.string(),
    quantity: z.string().optional(),
    optional: z.boolean().optional(),
  })).default([]),
});

export const tutorialSchema = z.object({
  slug: z.string(),
  frontmatter: tutorialFrontmatterSchema,
  content: z.string(),
});

// User preferences and storage schemas
export const userPreferencesSchema = z.object({
  favoritesTutorials: z.array(z.string()).default([]),
  materialChecklists: z.record(z.array(z.string())).default({}),
  theme: z.enum(["light", "dark", "system"]).default("system"),
});

// Category schema
export const categorySchema = z.object({
  name: z.string(),
  slug: z.string(),
  description: z.string(),
  tutorialCount: z.number(),
  icon: z.string(),
});

// Search and filter schemas  
export const searchFiltersSchema = z.object({
  query: z.string().default(""),
  category: z.string().optional(),
  difficulty: z.string().optional(),
  sort: z.enum(["newest", "popular", "difficulty", "duration"]).default("newest"),
  page: z.number().default(1),
});

// Export types
export type TutorialFrontmatter = z.infer<typeof tutorialFrontmatterSchema>;
export type Tutorial = z.infer<typeof tutorialSchema>;
export type UserPreferences = z.infer<typeof userPreferencesSchema>;
export type Category = z.infer<typeof categorySchema>;
export type SearchFilters = z.infer<typeof searchFiltersSchema>;
